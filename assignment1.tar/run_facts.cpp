/***************************************************
 * Program filename: run_facts.cpp
 * Author: Junhyeok Jeong
 * Date:4/15/2018
 * Description: implementation part of states and county's information
 * Input: each function arguments, command line arguments, minimum income, print type 
 * Output: sorted states and counties, largest popoulation state and county
****************************************************/

#include <iostream>
#include <fstream>
#include <string>
#include <cstring>
#include <cstdlib>
#include <algorithm>
#include "state_facts.h"

using namespace std;

int main(int argc, char** argv){
	
	if(is_valid_arguments(argv,argc) ==false){
		return 0;}
	
	string word,w_f; 
	int n;
	ifstream file(argv[4]);
	n=atoi(argv[2]);

	state* states=create_states(n);
	get_state_data(states,n,file);
	
	string answer;
	cout << "input an income value for checking counties which are higer than the input value: " << endl;
	getline(cin,answer);
	while(ask_income(answer) != true){
		cout << "input an income value for checking counties which are higer than the input value: " << endl;
		getline(cin,answer);}

	string answer_2;
	cout << "choose printing output method: S.print on the screen F.print on a file" << endl;
	getline(cin,answer_2);
	while(print_method(answer_2) !=true){
		cout << "choose printing output method: S.print on the screen F.print on a file" << endl;
		getline(cin,answer_2);}

	if(answer_2 == "S"){
		cout << "The state with largest population" << endl;
		state_large_pop(states,n);
		
		cout << "The county with largest population" << endl;
		county_large_pop(states,n);

		cout << "The counties are higher than the input minimum income" << endl;
		county_income_amount(states,n,atoi(answer.c_str()));
		
		cout << "The average house hold cost for all counties in a state" << endl;
		avg_household_cost(states,n);

		cout << "Sorting states by name" << endl;
		sort(states,states+n,compare_sn);
		for(int i=0; i<n; i++){
			cout << states[i].name << endl;} 
		
		cout << "Sorting states by population" << endl;
		sort(states,states+n);
		for(int i=0; i<n; i++){
			cout << states[i].name << endl;}
		
		cout << "Sorting counties in each states by name" << endl;
		for(int i=0; i<n; i++){
			sort(states[i].c,states[i].c+states[i].counties,compare_cn);
			}
		for(int i=0; i<n; i++){
			cout << states[i].name << endl;
			for(int j=0; j<states[i].counties; j++){
				cout << j+1 << ". " << states[i].c[j].name << endl;}
}
		cout << "Sorting counties in each states by population" << endl;
		 for(int i=0; i<n; i++){
			sort(states[i].c,states[i].c+states[i].counties);
			}
		for(int i=0; i<n; i++){
			cout << states[i].name << endl;
			for(int j=0; j<states[i].counties; j++){
				cout << j+1 << ". " << states[i].c[j].name << endl;}
}
}
	if(answer_2 =="F"){
		cout << "Write your file name except .txt" << endl;
		getline(cin,w_f);
		while(ask_filename(w_f) != true){
			cout << "Write your file anme except .txt" << endl;
			getline(cin,w_f);}
		w_f=w_f+".txt";
		ofstream wf;
		wf.open("temp.txt");
		
		wf << "The state with largest population" << endl;
		state_large_pop_2(states,n,wf);
		
		wf << "The county with largest population" << endl;
		county_large_pop_2(states,n,wf);

		wf << "The counties are higher than the input minimum income" << endl;
		county_income_amount_2(states,n,atoi(answer.c_str()),wf);
		
		wf << "The average house hold cost for all counties in a state" << endl;
		avg_household_cost_2(states,n,wf);

		wf << "Sorting states by name" << endl;
		sort(states,states+n,compare_sn);
		for(int i=0; i<n; i++){
			wf << states[i].name << endl;} 
		
		wf << "Sorting states by population" << endl;
		sort(states,states+n);
		for(int i=0; i<n; i++){
			wf << states[i].name << endl;}
		
		wf << "Sorting counties in each states by name" << endl;
		for(int i=0; i<n; i++){
			sort(states[i].c,states[i].c+states[i].counties,compare_cn);
			}
		for(int i=0; i<n; i++){
			wf << states[i].name << endl;
			for(int j=0; j<states[i].counties; j++){
				wf << j+1 << ". " << states[i].c[j].name << endl;}
}
		wf << "Sorting counties in each states by population" << endl;
		 for(int i=0; i<n; i++){
			sort(states[i].c,states[i].c+states[i].counties);
			}
		for(int i=0; i<n; i++){
			wf << states[i].name << endl;
			for(int j=0; j<states[i].counties; j++){
				wf << j+1 << ". " << states[i].c[j].name << endl;}
}
	wf.close();
	rename("temp.txt",w_f.c_str());
}

	
	file.close();
	delete_info(&states,n);		 	
		
}

	
