/***************************************************
 * Program filename: state_facts.h
 * Author: Junhyeok Jeong
 * Date:4/15/2018
 * Description: header file for prototypes of structures and functions
 * Input: nothing because just prototypes and libraries
 * Output: X
****************************************************/

#include <iostream>
#include <string>
#include <fstream>
#include <cstdlib>
#include <cstring>

using namespace std;

struct county {
	string name; // name of county
	string *city; // array of city names in county
	int cities; // number of cities in county
	int population; //total population of county
	float avg_income; //avg household income
	float avg_house; //avg household price
};

struct state {
	string name; // name of state
	struct county *c; //array of counties
	int counties; //number of counties in state
	int population; //total population of state
};

bool is_valid_arguments(char**, int);
state* create_states(int);
void get_state_data(state*, int, ifstream&);
county* create_counties(int);
void get_county_data(county*, int, ifstream&);
void delete_info(state**, int);
void state_large_pop(state*, int);
void state_large_pop_2(state*, int, ofstream&);
void county_large_pop(state*, int);
void county_large_pop_2(state*, int, ofstream&);
void county_income_amount(state*, int, int);
void county_income_amount_2(state*, int, int, ofstream&);
void avg_household_cost(state*, int);
void avg_household_cost_2(state*, int, ofstream&);
bool ask_income(string);
bool print_method(string);
bool ask_filename(string);
bool compare_sn(state const& lhs, state const& rhs);
bool operator<(const state& lhs, const state& rhs);
bool compare_cn(county const& lhs, county const& rhs);
bool operator<(const county& lhs, const county& rhs);
