/***************************************************
 * Program filename: state_facts.cpp
 * Author: Junhyeok Jeong
 * Date:4/15/2018
 * Description: definition part for manipulating states and county's information
 * Input: definitions of each functions, command line arguments, minimum income, print type
 * Output: sorted states and counties, largest popoulation state and county
****************************************************/
#include <iostream>
#include <string>
#include <fstream>
#include <sstream>
#include <cstdlib>
#include <algorithm>
#include "state_facts.h"

using namespace std;

/***********************************
 * Function:is_valid_arguments
 * Description: check command line arguments for error handling
 * Parameters:char* argv[], int argc
 * Pre-Conditions: take 2 argument as C-string
 * Post-Conditions: output should be true for executing this file
***********************************/ 

bool is_valid_arguments(char* argv[], int argc){

	if(argc <2){
		cout << "Warning ! check your arguments ! " << endl;
		return false;
}
	if(argc !=5){
		cout << "Warning ! check the number of arguments" << endl;
		return false;
}
	if(string(argv[1]) != "-s"){
		cout << "Warning ! check your second argument" << endl;
		return false;
}
	if(string(argv[3]) != "-f"){
		cout << "Warning ! check your fourth argument" << endl;
		return false;
}
	if(atoi(argv[2]) <= 0){
		cout << "Warning ! check your integer" << endl;
		cout << "Please input again: " << endl;
		cin >> argv[2];
		is_valid_arguments(argv,argc);
}

	for (int i=0; i<strlen(argv[2]); i++){
		if(string(argv[2])[i] != '0' && string(argv[2])[i] != '1' &&  string(argv[2])[i] != '2' &&  string(argv[2])[i] != '3' &&  string(argv[2])[i] != '4' && string(argv[2])[i] != '5' &&  string(argv[2])[i] != '6' &&  string(argv[2])[i] != '7' &&  string(argv[2])[i] != '8' &&  string(argv[2])[i] != '9'){
			cout << "Warning ! check your integer" << endl;
			cout << "Please input again: " << endl;
			cin >> argv[2];
			is_valid_arguments(argv,argc);}
} 

	if(string(argv[4]) != "states1.txt"){
		cout << "Warning ! check your filename " << endl;
		cout << "Please input valid filename (states1.txt) " << endl;
		cin >> argv[4];
		is_valid_arguments(argv,argc);
}
	return true;
}
/***********************************
 * Function:create_states
 * Description: create state arrays on the heap
 * Parameters:int arg2
 * Pre-Conditions: take 1 argument as int value(command line argument)
 * Post-Conditions: creating a number of array as much command line argument
***********************************/ 

state* create_states(int arg2){
	state* states = new state[arg2];
	return states;
}
/***********************************
 * Function:create_counties
 * Description: create county arrays on the heap
 * Parameters:int county_num
 * Pre-Conditions: take 1 argument as int value(county_number)
 * Post-Conditions: creating a number of array as much command line argument
***********************************/ 

county* create_counties(int county_num){
	struct county* counties = new county[county_num];
	return counties;
}
/***********************************
 * Function:get_state_data
 * Description: take states and counties data in a text file 
 * Parameters:state* states, int arg2, ifstream& file
 * Pre-Conditions: take 3 argument as int, state, ifstream value(command line argument)
 * Post-Conditions: the information existed in arrays 
***********************************/ 

void get_state_data(state* states, int arg2, ifstream& file){
	string line, word;
	char ch;
	int counter=0 , i =0;
 
	file.seekg(0,file.beg);

	if(file.is_open()){
		while(arg2-i){
			getline(file,line);
			for(int j=0; j<line.length(); j++){
				ch=line[j];
				if(ch==' '){
					if(counter==0){
						states[i].name=word;
						counter++;}
					else{
						istringstream buffer(word);
						buffer >> states[i].population;
						counter=0;}
					word="";}
				else{
					word+=ch;}
}
			istringstream buffer(word);;
			buffer >> states[i].counties;
			states[i].c=create_counties(states[i].counties);
			get_county_data(states[i].c,states[i].counties,file);
			i++;
			word="";
}
}
	else{
		cout << "File did not open" << endl;}
	file.close();
	
}
/***********************************
 * Function:get_county_data
 * Description: take states and counties data in a text file 
 * Parameters:county* c, int n, ifstream& file
 * Pre-Conditions: take 3 argument as int, county, ifstream value(command line argument)
 * Post-Conditions: the information existed in arrays 
***********************************/ 

void get_county_data(county* c, int n, ifstream& file){
	string line, word, *cities;
	int counter=0, index_2=0, house;
	float a_i=0.00f;

	for(int i=0; i<n; i++){
		getline(file, line);
		for(int j=0; j<line.length(); j++){
			if(line[j] == ' '){
				if(counter==0){
					c[i].name=word;
					counter=counter+1;}
				else if(counter==1){
					c[i].population=atoi(word.c_str());
					if(c[i].population==0){
						c[i].population++;}
					counter=counter+1;}
				else if(counter==2){
					a_i=atof(word.c_str());
					counter=counter+1;}
				else if(counter==3){
					house=atoi(word.c_str());
					if(house==0){
						house++;}
					c[i].avg_income= (float)a_i/house;
					c[i].avg_house=(float)a_i/c[i].population;
					counter=counter+1;}
				else if(counter==4){
					c[i].cities=atoi(word.c_str());
					cities= new string[c[i].cities];
					counter=counter+1;}
				else{
					cities[counter-5]=word;
					counter=counter+1;}
				word="";}
				else {
					word=word+line[j];}
}
				cities[counter-5]=word;
				c[i].city=cities;
				delete [] cities;
				counter=0;
				word="";}
}
/***********************************
 * Function:delete_info
 * Description: delete dynamic arrays and information in state structure
 * Parameters:state** s, int arg2
 * Pre-Conditions: take 2 arguments as state type and integer
 * Post-Conditions: memory free after this function 
***********************************/ 
void delete_info(state** s, int arg2){
	for(int i=0; i<arg2; i++){
		delete [] (*s)[i].c;
}
	delete [] *s;
	s=NULL;
}
/***********************************
 * Function:state_large_pop
 * Description: choose the largest population state
 * Parameters:state* s, int arg2
 * Pre-Conditions: take 2 arguments as state and integer type
 * Post-Conditions: After this function, chosen a state value
***********************************/ 
void state_large_pop(state* s, int arg2){
	int pop=0;
	for(int i=0; i<arg2; i++){
		if(pop<s[i].population){
			pop=s[i].population;}
}
	for(int i=0; i<arg2; i++){
		if(pop==s[i].population){
		cout << s[i].name << ", " << pop << endl;}
}
}
/***********************************
 * Function:state_large_pop_2
 * Description: choose the largest population state for writing another text file
 * Parameters:state* s, int arg2, ofstream& wf
 * Pre-Conditions: take 2 arguments as state and integer type, ofstream
 * Post-Conditions: After this function, chosen a state value
***********************************/ 
void state_large_pop_2(state* s, int arg2, ofstream& wf){
	int pop=0;
	for(int i=0; i<arg2; i++){
		if(pop<s[i].population){
			pop=s[i].population;}
}
	for(int i=0; i<arg2; i++){
		if(pop==s[i].population){
		wf << s[i].name << ", " << pop << endl;}
}
}
	
/***********************************
 * Function:county_large_pop
 * Description: choose the largest population county
 * Parameters:state* s, int arg2
 * Pre-Conditions: take 2 arguments as state and integer type
 * Post-Conditions: After this function, chosen a county value
***********************************/ 

void county_large_pop(state* s, int arg2){
	int pop=0;

	for(int i=0; i<arg2; i++){
		for(int j=0; j<s[i].counties; j++){
			if(pop<s[i].c[j].population){
				pop=s[i].c[j].population;}
}
}
	for(int i=0; i<arg2; i++){
		for(int j=0; j<s[i].counties; j++){
			if(pop==s[i].c[j].population){
				cout<<s[i].c[j].name << ", " << pop << endl;}
}
}
}
/***********************************
 * Function:county_large_pop_2
 * Description: choose the largest population county for writing another text file
 * Parameters:state* s, int arg2,ofstream& wf
 * Pre-Conditions: take 3 arguments as state and integer type,  ofstream
 * Post-Conditions: After this function, chosen a county value
***********************************/ 

void county_large_pop_2(state* s, int arg2, ofstream& wf){
	int pop=0;

	for(int i=0; i<arg2; i++){
		for(int j=0; j<s[i].counties; j++){
			if(pop<s[i].c[j].population){
				pop=s[i].c[j].population;}
}
}
	for(int i=0; i<arg2; i++){
		for(int j=0; j<s[i].counties; j++){
			if(pop==s[i].c[j].population){
				wf<<s[i].c[j].name << ", " << pop << endl;}
}
}
}

/***********************************
 * Function:county_income_amount
 * Description: filtering counties which have higher income than input value in main function
 * Parameters:state* s, int arg2, int filter
 * Pre-Conditions: take 3 arguments as state and integer type
 * Post-Conditions: After this function, filtering higher income counties 
***********************************/ 

void county_income_amount(state* s, int arg2, int filter){
	for(int i=0; i<arg2; i++){
		for(int j=0; j<s[i].counties; j++){
			if(filter<(s[i].c[j].population*s[i].c[j].avg_house)){
				cout<<s[i].c[j].name << " ";}
}
}
	cout << endl;
}

/***********************************
 * Function:county_income_amount_2
 * Description: filtering counties which have higher income than input value in main function
 * Parameters:state* s, int arg2, int filter,ofstream& type
 * Pre-Conditions: take 4 arguments as state, integer, and ofstream type
 * Post-Conditions: After this function, filtering higher income counties for writing file
***********************************/ 

void county_income_amount_2(state* s, int arg2, int filter, ofstream& wf){
	for(int i=0; i<arg2; i++){
		for(int j=0; j<s[i].counties; j++){
			if(filter<(s[i].c[j].population*s[i].c[j].avg_house)){
				wf<<s[i].c[j].name << " ";}
}
}
	wf << endl;
}
/***********************************
 * Function:avg_household_cost
 * Description: function for average house hold cost
 * Parameters:state* s, int arg2
 * Pre-Conditions: take 2 arguments as state and integer type
 * Post-Conditions: take average house hold cost each states
***********************************/ 

void avg_household_cost(state* s, int arg2){
	float avg=0.00f;
	
	for(int i=0; i<arg2; i++){
		avg=0.00f;
		
		for(int j=0; j<s[i].counties; j++){
			avg+=s[i].c[j].avg_house;}
		if(s[i].counties!=0){
			avg/=s[i].counties;}

		cout << s[i].name<<": " << avg << endl;
	}
}
/***********************************
 * Function:avg_household_cost_2
 * Description: function for average house hold cost
 * Parameters:state* s, int arg2,ofstream&
 * Pre-Conditions: take 3 arguments as state, integer, and ofstream type
 * Post-Conditions: take average house hold cost each states for writing file
***********************************/ 

void avg_household_cost_2(state* s, int arg2, ofstream& wf){
	float avg=0.00f;
	
	for(int i=0; i<arg2; i++){
		avg=0.00f;
		
		for(int j=0; j<s[i].counties; j++){
			avg+=s[i].c[j].avg_house;}
		if(s[i].counties!=0){
			avg/=s[i].counties;}

		wf << s[i].name<<": " << avg << endl;
	}
}
/***********************************
 * Function:print_method
 * Description: ask print method to user
 * Parameters:string answer_2
 * Pre-Conditions: take 1 argument as string
 * Post-Conditions: take S or F and then output is on the screen or writing file
***********************************/ 


bool print_method(string answer_2){
	if(answer_2 != "S" && answer_2 != "F"){
		cout << "Warning ! Check your input !" << endl;
		return false;}
	return true;
	
}
/***********************************
 * Function:ask_income
 * Description: ask minimum income for filtering counties
 * Parameters:string a
 * Pre-Conditions: take 1 argument as string
 * Post-Conditions: take a user input and then setting minimum income
***********************************/ 
bool ask_income(string a){	
	for(int i=0; i<a.length(); i++){
		if(a[i] != '0' && a[i] !=  '1' && a[i] != '2' && a[i] != '3' && a[i] != '4' && a[i] != '5' && a[i] != '6' && a[i] != '7' && a[i] != '8' && a[i] != '9'){
		cout <<  "Warning ! check your input !" << endl;
		return false;}
}
	return true;
}
/***********************************
 * Function:ask_filename
 * Description: checking fileanme for error handling
 * Parameters:string b
 * Pre-Conditions: take 1 argument as string
 * Post-Conditions: if return false, then ask again. if return true, then it is accepted
***********************************/ 
bool ask_filename(string b){	
	if(b== ""){
		cout << "Warning ! Check your file name" << endl;
		return false;}
	return true;
}
 /***********************************
 * Function:compare_sn
 * Description: function for sorting states by name
 * Parameters:state const& lhs, state const& rhs
 * Pre-Conditions: take 2 arguments as states
 * Post-Conditions: return output after comparing inputs
***********************************/ 
bool compare_sn(state const& lhs, state const& rhs)
{return lhs.name < rhs.name;}
 /***********************************
 * Function:operator<
 * Description: set operator < meaning for comapring state values
 * Parameters:const state& lhs, const state& rhs
 * Pre-Conditions: take 2 arguments as constant
 * Post-Conditions: sorted state values by population
***********************************/ 

bool operator<(const state& lhs, const state& rhs)
{return rhs.population < lhs.population;}
 /***********************************
 * Function:compare_cn
 * Description: function for sorting counties by name
 * Parameters:county const& lhs, county const& rhs
 * Pre-Conditions: take 2 arguments as counties
 * Post-Conditions: return output after comparing inputs
***********************************/ 

bool compare_cn(county const& lhs, county const& rhs)
{return lhs.name < rhs.name;}
 /***********************************
 * Function:operator<
 * Description: set operator < meaning for comparing state values
 * Parameters: const county& lhs, const county& rhs
 * Pre-Conditions: take 2 arguments as contant
 * Post-Conditions: sorted county value by population
***********************************/ 

bool operator<(const county& lhs, const county& rhs)
{return rhs.population < lhs.population;}

