/***************************************************
 * Program filename: insect.h
 * Author: Junhyeok Jeong
 * Date:5/27/2018
 * Description: header file part for property class
 * Input: function's prototypes
 * Output: x
****************************************************/

#include <iostream>
#include <cstdlib>
#include <string>
#include <vector>
#ifndef INSECT_H
#define INSECT_H

using namespace std;

class Insect{
	private:
		int food;


	public:
		Insect();
		Insect(int);
		int get_food() const;
		void set_food(int);

		//copy constructor
		Insect(const Insect&);
		//assignment operator overload
		const Insect& operator=(const Insect &);
		//destructor
		~Insect();


		void game_start();
		void menu_prompt();

};
#endif
