/************************************************
 * Program filename: driver.cpp
 * Author: Junhyeok Jeong
 * Date:5/27/2018
 * Description: implementation part of driver class
 * Input: main part
 * Output: run program
*************************************************/

#include <iostream>
#include <vector>
#include <stdio.h>
#include "insect.h"
#include "ant.h"
#include "bee.h"

using namespace std;



int main(){
	int turn_counter = 1;
	Insect game =Insect(50);
	Ant start;
	vector<Ant*> ant_arr;
	start.extend_arr(ant_arr);
	vector<Ant*> body_arr;
	start.extend_arr(body_arr);

	Bee bee_arr[20][10];
	int bee_counter[20][10] = { 0 };

	int ant_counter[10] = { 0 };
	int body_counter[10] = { 0 };

	game.game_start();
	while (bee_arr[20][10].lose_game(bee_arr, bee_counter) != true) {
		bee_arr[20][10].bee_maker(bee_arr, bee_counter, turn_counter);
		bee_arr[20][10].bee_stat(bee_arr, bee_counter);
		ant_arr[0]->ant_maker(game, ant_arr, body_arr, ant_counter, body_counter);
		ant_arr[0]->board_stat(game, ant_arr, body_arr, ant_counter, body_counter);
		ant_arr[0]->board_stat_2(game, ant_arr, body_arr, ant_counter, body_counter);
		ant_arr[0]->ant_attack(game, ant_arr, bee_arr, ant_counter, bee_counter);
		bee_arr[20][10].bee_rip(bee_arr, bee_counter);
		ant_arr[0]->bee_move_attack(ant_arr, body_arr, bee_arr, ant_counter, body_counter, bee_counter);
		ant_arr[0]->ant_dead(ant_arr, body_arr, ant_counter, body_counter);
		turn_counter = turn_counter + 1;
		if (bee_arr[20][10].win_game(bee_arr, bee_counter) == true) {
			cout << "Congratulation !! You are WINNER !! " << endl;
			ant_arr[0]->ant_clean(ant_arr, body_arr, ant_counter, body_counter);
			break;
		}
	}
	if (bee_arr[20][10].lose_game(bee_arr, bee_counter) == true) {
		cout << "R.I.P OUR QUEEN IS DEAD YOU ARE LOSE !!" << endl;
		ant_arr[0]->ant_clean(ant_arr, body_arr, ant_counter, body_counter);
	}


	return 0;
}
