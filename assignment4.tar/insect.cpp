/***************************************************
 * Program filename: insect.cpp
 * Author: Junhyeok Jeong
 * Date:5/27/2018
 * Description: header file part for property class
 * Input: function's parameters and definitions
 * Output: x
****************************************************/

#include <iostream>
#include <cstdlib>
#include <string>
#include <vector>
#include "insect.h"

using namespace std;


//constructor
Insect::Insect() {
	food = 0;
}

Insect::Insect(int f) {
	food = f;
}

//accessor
int Insect::get_food() const { return food; }

//mutator
void Insect::set_food(int f) { food = f; }

//copy constructor
Insect::Insect(const Insect& copy) {
	food = copy.food;
}

//assignment operator overload
const Insect& Insect::operator=(const Insect& copy) {
	food = copy.food;

	return *this;
}

//destructor
Insect::~Insect(){}

/***********************************
 * Function: game_start
 * Description: print game start messages
 * Parameters: x
 * Pre-Conditions: x
 * Post-Conditions: print sentences well
***********************************/ 

void Insect::game_start() {
	cout << "Welcome to ANTS VS SOMEBEES !!" << endl;
	cout << "Protect our ANT QUEEN !" << endl;
	cout << "-----------------------" << endl;
	cout << "|    GAME   START     |" << endl;
	cout << "-----------------------" << endl;
	cout << endl;
	cout << endl;
	cout << "Battle ground is setting ........" << endl;
	
	cout << "      1        2       3       4       5       6       7       8       9       10   " << endl;
	cout << "   _________________________________________________________________________________" << endl;
	cout << "   | Q   E |       |       |       |       |       |       |       |       |  BEE  |" << endl;
	cout << "   | E   E |       |       |       |       |       |       |       |       |  H I  |" << endl;
	cout << "   |___N___|_______|_______|_______|_______|_______|_______|_______|_______|__V_E__|" << endl;
	cout << endl;

}

/***********************************
 * Function: menu_prompt
 * Description: print menu messages
 * Parameters: x
 * Pre-Conditions: x
 * Post-Conditions: print sentences well
***********************************/ 

void Insect::menu_prompt() {
	cout << "What type of ant you want to spawn??" << endl;
	cout << "1. Harvester (food cost : 2)" << endl;
	cout << "2. Thrower (food cost : 4)" << endl;
	cout << "3. Fire (food cost : 4)" << endl;
	cout << "4. Long Thrower(food cost : 3)" << endl;
	cout << "5. Short Thrower (food cost : 3)" << endl;
	cout << "6. Wall (food cost : 4)" << endl;
	cout << "7. Ninja (food cost : 6)" << endl;
	cout << "8. Bodyguard (food cost : 4)" << endl;
}




