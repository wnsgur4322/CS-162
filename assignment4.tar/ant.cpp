/***************************************************
 * Program filename: ant.cpp
 * Author: Junhyeok Jeong
 * Date:5/27/2018
 * Description: header file part for property class
 * Input: function's parameters and definitions
 * Output: x
****************************************************/

#include <iostream>
#include <cstdlib>
#include <string>
#include <vector>
#include "ant.h"

Ant::Ant() {
	armor = 0;
	food_cost = 0;
	position = "";
}

Ant::Ant(int ar, int fc, string ps) {

armor = ar;
food_cost = fc;
position = ps;

}

//accessor
int Ant::get_food_cost() const { return food_cost; }
int Ant::get_armor() const { return armor; }
string Ant::get_position() const { return position; }

//mutator
void Ant::set_food_cost(int fc) { food_cost = fc; }
void Ant::set_armor(int ar) { armor = ar; }
void Ant::set_position(string ps) { position = ps; }

//copy constructor
Ant::Ant(const Ant& copy) {
	
	armor = copy.armor;
	food_cost = copy.food_cost;
	position = copy.position;

}
//assignment operator overload
const Ant& Ant::operator=(const Ant& copy) {
	armor = copy.armor;
	food_cost = copy.food_cost;
	position = copy.position;
}

//destructor
Ant::~Ant() {}

//constructors and destructors of child ants
Harvester::Harvester() {
	armor = 1;
	food_cost = 2;
	position = "Harvester";
}
Harvester::~Harvester() {}
Thrower::Thrower() {
	attack = 1;
	armor = 1;
	food_cost = 4;
	position = "Thrower";
}
Thrower::~Thrower() {}
Fire::Fire() {
	armor = 1;
	food_cost = 4;
	position = "Fire";
}
Fire::~Fire() {}
Long_thrower::Long_thrower() {
	attack = 1;
	armor = 1;
	food_cost = 3;
	position = "Longthrower";
}
Long_thrower::~Long_thrower() {}
Short_thrower::Short_thrower() {
	attack = 1;
	armor = 1;
	food_cost = 3;
	position = "Shortthrower";
}
Short_thrower::~Short_thrower() {}
Wall::Wall() {
	armor = 4;
	food_cost = 4;
	position = "Wall";
}
Wall::~Wall() {}
Ninja::Ninja() {
	attack = 1;
	armor = 99999;
	food_cost = 6;
	position = "Ninja";
}
Ninja::~Ninja() {}
Bodyguard::Bodyguard() {
	armor = 2;
	food_cost = 4;
	position = "Bodyguard";
}
Bodyguard::~Bodyguard() {}

/***********************************
 * Function: rip_ant
 * Description: parent's function of polymorphism
 * Parameters: x
 * Pre-Conditions: polymorphism is working well
 * Post-Conditions: print sentence
***********************************/ 

void Ant::rip_ant() {
	cout << "Ant is dead !! RIP" << endl;
}

/***********************************
 * Function: ability
 * Description: parent's function of polymorphism
 * Parameters: Insect&, vector, Bee, int, int, int
 * Pre-Conditions: polymorphism is working well
 * Post-Conditions: x
***********************************/
 
void Ant::ability(Insect& game, vector<Ant*> &ant_arr, Bee bee_arr[][10], int ant_counter[10], int bee_counter[][10], int index) {}

/***********************************
 * Function: rip_ant
 * Description: child's function of polymorphism
 * Parameters: x
 * Pre-Conditions: polymorphism is working well
 * Post-Conditions: print sentence
***********************************/ 
void Harvester::rip_ant() {
	cout << "Harvester is dead !! RIP " << endl;
}
/***********************************
 * Function: ability
 * Description: child's function of polymorphism
 * Parameters: Insect, vector, Bee, int, int, int
 * Pre-Conditions: polymorphism is working well
 * Post-Conditions: activate unique ability
***********************************/ 
void Harvester::ability(Insect& game, vector<Ant*> &ant_arr, Bee bee_arr[][10], int ant_counter[10], int bee_counter[][10], int index) {
	cout << "Harvester collected food !" << endl;
	game.set_food(game.get_food() + 1);
	cout << "Player's food amount : " << game.get_food() << endl;

}
/***********************************
 * Function: rip_ant
 * Description: child's function of polymorphism
 * Parameters: x
 * Pre-Conditions: polymorphism is working well
 * Post-Conditions: print sentence
***********************************/ 
void Thrower::rip_ant() {
	cout << "Thorwer is dead !! RIP" << endl;
}

/***********************************
 * Function: ability
 * Description: child's function of polymorphism
 * Parameters: Insect, vector, Bee, int, int, int
 * Pre-Conditions: polymorphism is working well
 * Post-Conditions: activate unique ability
***********************************/ 
void Thrower::ability(Insect& game, vector<Ant*> &ant_arr, Bee bee_arr[][10], int ant_counter[10], int bee_counter[][10], int index) {
	cout << "Thrower Ant on the battle ground  " << index+1 << endl;
	cout << "Thrower attack !" << endl;
	for (int i = 0; i < 20; i++) {
		if (bee_counter[i][index] == 1) {
			bee_arr[i][index].set_armor(bee_arr[i][index].get_armor() - 1);
			cout << "the bee No." << bee_arr[i][index].get_bee_num() << "  has damaged on the battleground " << index+1 << endl; 
			break;
		}
	}
}

/***********************************
 * Function: rip_ant
 * Description: child's function of polymorphism
 * Parameters: x
 * Pre-Conditions: polymorphism is working well
 * Post-Conditions: print sentence
***********************************/ 
void Fire::rip_ant() {
	cout << "Fire is dead !! RIP" << endl;
}

/***********************************
 * Function: ability
 * Description: child's function of polymorphism
 * Parameters: Insect, vector, Bee, int, int, int
 * Pre-Conditions: polymorphism is working well
 * Post-Conditions: activate unique ability
***********************************/ 
void Fire::ability(Insect& game, vector<Ant*> &ant_arr, Bee bee_arr[][10],int ant_counter[10], int bee_counter[][10], int index) {
	if (ant_arr[index]->get_armor() <= 0) {
		cout << "Fire's bomb is exploded !! BOOOM ! " << endl;
		delete ant_arr[index];
		ant_arr[index] = NULL;
		ant_counter[index] = 0;
		for (int i = 0; i < 20; i++) {
			if (bee_counter[i][index] == 1) {
				bee_arr[i][index].set_armor(0);
				cout << "the bee No." << bee_arr[i][index].get_bee_num() << "  has damaged on the battleground " << index+1 << endl;
			}
		}
	}
}

/***********************************
 * Function: rip_ant
 * Description: child's function of polymorphism
 * Parameters: x
 * Pre-Conditions: polymorphism is working well
 * Post-Conditions: print sentence
***********************************/ 
void Long_thrower::rip_ant() {
	cout << "Long thrower is dead !! RIP" << endl;
}

/***********************************
 * Function: ability
 * Description: child's function of polymorphism
 * Parameters: Insect, vector, Bee, int, int, int
 * Pre-Conditions: polymorphism is working well
 * Post-Conditions: activate unique ability
***********************************/ 
void Long_thrower::ability(Insect& game, vector<Ant*> &ant_arr, Bee bee_arr[][10], int ant_counter[10], int bee_counter[][10], int index) {
	int active = 0;
	cout << "Long Thrower Ant on the battle ground  " << index+1 << endl;
	cout << "Long Thrower attack !" << endl;
	for (int i = 0; i < 20; i++) {if (bee_counter[i][index] == 1) {bee_arr[i][index].set_armor(bee_arr[i][index].get_armor() - 1);
			cout << "the bee No." << bee_arr[i][index].get_bee_num() << "  has damaged on the battleground " << index+1 << endl;
			active = 1;}}
	if (active == 0 && (index + 1)  <=9) {for (int i = 0; i < 20; i++) {if (bee_counter[i][index + 1] == 1) {bee_arr[i][index + 1].set_armor(bee_arr[i][index + 1].get_armor() - 1);
				cout << "the bee No." << bee_arr[i][index + 1].get_bee_num() << "  has damaged on the battleground " << index + 2 << endl;
				active = 1;}}}
	if (active == 0 && (index + 2) <=9) {for (int i = 0; i < 20; i++) {if (bee_counter[i][index + 2] == 1) {bee_arr[i][index + 2].set_armor(bee_arr[i][index + 2].get_armor() - 1);
				cout << "the bee No." << bee_arr[i][index + 2].get_bee_num() << "  has damaged on the battleground " << index + 3 << endl;
				active = 1;}}}
	if (active == 0 && (index + 3) <=9) {for (int i = 0; i < 20; i++) {if (bee_counter[i][index + 3] == 1) {bee_arr[i][index + 3].set_armor(bee_arr[i][index + 3].get_armor() - 1);
				cout << "the bee No." << bee_arr[i][index + 3].get_bee_num() << "  has damaged on the battleground " << index + 4 << endl;
				active = 1;}}}
	if (active == 0 && (index + 4) <=9) {for (int i = 0; i < 20; i++) {if (bee_counter[i][index + 4] == 1) {bee_arr[i][index + 4].set_armor(bee_arr[i][index + 4].get_armor() - 1);
				cout << "the bee No." << bee_arr[i][index + 4].get_bee_num() << "  has damaged on the battleground " << index + 5 << endl;
				active = 1;}}}
}

/***********************************
 * Function: rip_ant
 * Description: child's function of polymorphism
 * Parameters: x
 * Pre-Conditions: polymorphism is working well
 * Post-Conditions: print sentence
***********************************/ 
void Short_thrower::rip_ant() {
	cout << "Short thrower is dead !! RIP" << endl;
}

/***********************************
 * Function: ability
 * Description: child's function of polymorphism
 * Parameters: Insect, vector, Bee, int, int, int
 * Pre-Conditions: polymorphism is working well
 * Post-Conditions: activate unique ability
***********************************/ 
void Short_thrower::ability(Insect& game, vector<Ant*> &ant_arr, Bee bee_arr[][10], int ant_counter[10], int bee_counter[][10], int index) {
	int active = 0;
	cout << "Short Thrower Ant on the battle ground  " << index + 1 << endl;
	cout << "Short Thrower attack !" << endl;
	for (int i = 0; i < 20; i++) {
		if (bee_counter[i][index] == 1) {
			bee_arr[i][index].set_armor(bee_arr[i][index].get_armor() - 1);
			cout << "the bee No." << bee_arr[i][index].get_bee_num() << "  has damaged on the battleground " << index + 1 << endl;
			active = 1;
		}
	}
	if (active == 0 && (index + 1) <= 9) {
		for (int i = 0; i < 20; i++) {
			if (bee_counter[i][index + 1] == 1) {
				bee_arr[i][index + 1].set_armor(bee_arr[i][index + 1].get_armor() - 1);
				cout << "the bee No." << bee_arr[i][index + 1].get_bee_num() << "  has damaged on the battleground " << index + 2 << endl;
				active = 1;
			}
		}
	}
	if (active == 0 && (index + 2) <= 9) {
		for (int i = 0; i < 20; i++) {
			if (bee_counter[i][index + 2] == 1) {
				bee_arr[i][index + 2].set_armor(bee_arr[i][index + 2].get_armor() - 1);
				cout << "the bee No." << bee_arr[i][index + 2].get_bee_num() << "  has damaged on the battleground " << index + 3 << endl;
				active = 1;
			}
		}
	}
}

/***********************************
 * Function: rip_ant
 * Description: child's function of polymorphism
 * Parameters: x
 * Pre-Conditions: polymorphism is working well
 * Post-Conditions: print sentence
***********************************/ 
void Wall::rip_ant() {
	cout << "Wall is dead !! RIP" << endl;
}

/***********************************
 * Function: rip_ant
 * Description: child's function of polymorphism
 * Parameters: x
 * Pre-Conditions: polymorphism is working well
 * Post-Conditions: print sentence
***********************************/ 
void Ninja::rip_ant() {
	cout << "NEVER DIE NINJA !!" << endl;
}

/***********************************
 * Function: ability
 * Description: child's function of polymorphism
 * Parameters: Insect, vector, Bee, int, int, int
 * Pre-Conditions: polymorphism is working well
 * Post-Conditions: activate unique ability
***********************************/ 
void Ninja::ability(Insect& game, vector<Ant*> &ant_arr, Bee bee_arr[][10], int ant_counter[10], int bee_counter[][10], int index) {
	cout << "Ninja Ant on the battle ground  " << index+1 << endl;
	cout << "Ninja embushed !" << endl;
	for (int i = 0; i < 20; i++) {
		if (bee_counter[i][index] == 1) {
			bee_arr[i][index].set_armor(bee_arr[i][index].get_armor() - 1);
			cout << "the bee No." << bee_arr[i][index].get_bee_num() << "  has damaged on the battleground " << index << endl;
		}
	}
}

/***********************************
 * Function: rip_ant
 * Description: child's function of polymorphism
 * Parameters: x
 * Pre-Conditions: polymorphism is working well
 * Post-Conditions: print sentence
***********************************/ 

void Bodyguard::rip_ant() {
	cout << "Bodygaurd is dead !! RIP" << endl;
}

/***********************************
 * Function: num_check
 * Description: check string for error handling
 * Parameters: string 
 * Pre-Conditions: take 1 argument as string
 * Post-Conditions: bool checking
***********************************/ 
bool Ant::num_check(string& a) {
	if (a != "1" && a != "2" && a != "3" && a != "4" && a != "5" && a != "6" && a != "7" && a != "8") {
		cout << "check you input !! " << endl;
		return false;
	}
	return true;
}

/***********************************
 * Function: food_check
 * Description: check string for error handling
 * Parameters: string , food
 * Pre-Conditions: take 2 argument as string
 * Post-Conditions: bool checking
***********************************/ 

bool Ant::food_check(string& a, int& food) {
	if (a == "1") {
		if (food < 2) {
			cout << "Food is not enough !!" << endl;
			return false;
		}
	}
	if (a == "2" || a == "3" || a == "6" || a == "8") {
		if (food < 4) {
			cout << "Food is not enough !!" << endl;
			return false;
		}
	}
	if (a == "4" || a == "5") {
		if (food < 3) {
			cout << "Food is not enough !!" << endl;
			return false;
		}
	}
	if (a == "7") {
		if (food < 6) {
			cout << "Food is not enough !!" << endl;
			return false;
		}
	}
	return true;
}

/***********************************
 * Function: take_food
 * Description: food taking from generate ant
 * Parameters: Insect, string
 * Pre-Conditions: take 2 argument as object and string
 * Post-Conditions: food taken
***********************************/ 

void Ant::take_food(Insect& game, string& a) {
	if (a == "1") {
		cout << "The diligent ant is ready for battle !!" << endl;
		game.set_food(game.get_food() - 2);
	}
	if (a == "2" || a == "3" || a == "6" || a == "8") {
		cout << "The brave ant is ready for battle !!" << endl;
		game.set_food(game.get_food() - 4);
	}
	if (a == "4" || a == "5") {
		cout << "The brave ant is ready for battle !!" << endl;
		game.set_food(game.get_food() - 3);
	}
	if (a == "7") {
		cout << "The Special ant is ready for battle !!" << endl;
		game.set_food(game.get_food() - 6);
	}
}

/***********************************
 * Function: extend_arr
 * Description: extending vector size
 * Parameters: vector
 * Pre-Conditions: take 1 argument as vector
 * Post-Conditions: extended to size 10
***********************************/ 

void Ant::extend_arr(vector<Ant*> &arr) {
	for (int i = 0; i < 10; i++) {
		arr.push_back(new Ant);
		delete arr[i];
		arr[i] = NULL;
	}
}

/***********************************
 * Function: location_check
 * Description: check string for error handling
 * Parameters: string 
 * Pre-Conditions: take 1 argument as string
 * Post-Conditions: bool checking
***********************************/ 

bool Ant::location_check(string& b) {
	if (b != "2" && b != "3" && b != "4" && b != "5" && b != "6" && b != "7" && b != "8" && b != "9" && b != "10") {
		cout << "Warning !! Check your input !! " << endl;
		return false;
	}
	return true;
}

/***********************************
 * Function: empty_check
 * Description: check string for error handling
 * Parameters: string, int
 * Pre-Conditions: take 2 argument as string
 * Post-Conditions: bool checking
***********************************/ 

bool Ant::empty_check(int ant_counter[10], string& b){
	if (b == "2") {if (ant_counter[1] == 1 || ant_counter[1] == 2) {cout << "Warning !! There is other ant already !!" << endl;
		return false;}}
	if (b == "3") {if (ant_counter[2] == 1 || ant_counter[2] == 2) { cout << "Warning !! There is other ant already !!" << endl;
		return false;}}
	if (b == "4") {if (ant_counter[3] == 1 || ant_counter[3] == 2) { cout << "Warning !! There is other ant already !!" << endl;
		return false;}}
	if (b == "5") {if (ant_counter[4] == 1 || ant_counter[4] == 2) { cout << "Warning !! There is other ant already !!" << endl;
		return false;}}
	if (b == "6") {if (ant_counter[5] == 1 || ant_counter[5] == 2) {cout << "Warning !! There is other ant already !!" << endl;
			return false;}}
	if (b == "7") {if (ant_counter[6] == 1 || ant_counter[6] == 2) {cout << "Warning !! There is other ant already !!" << endl;
			return false;}}
	if (b == "8") {if (ant_counter[7] == 1 || ant_counter[7] == 2) {cout << "Warning !! There is other ant already !!" << endl;
			return false;}}
	if (b == "9") {if (ant_counter[8] == 1 || ant_counter[8] == 2) {cout << "Warning !! There is other ant already !!" << endl;
			return false;}}
	if (b == "10") {if (ant_counter[9] == 1 || ant_counter[9] == 2) {cout << "Warning !! There is other ant already !!" << endl;
			return false;}}
	return true;
}

/***********************************
 * Function: body_empty_check
 * Description: check string for error handling
 * Parameters: string, int 
 * Pre-Conditions: take 2 argument as string and int array
 * Post-Conditions: bool checking
***********************************/ 

bool Ant::body_empty_check(int body_counter[10], string& b) {
		if (b == "2") {if (body_counter[1] == 1) {cout << "Warning !! Other bodyguard is already existed in there !! " << endl;
				return false;}}
		if (b == "3") {if (body_counter[2] == 1) {cout << "Warning !! Other bodyguard is already existed in there !! " << endl;
				return false;}}
		if (b == "4") {if (body_counter[3] == 1) {cout << "Warning !! Other bodyguard is already existed in there !! " << endl;
				return false;}}
		if (b == "5") {if (body_counter[4] == 1) {cout << "Warning !! Other bodyguard is already existed in there !! " << endl;
				return false;}}
		if (b == "6") {if (body_counter[5] == 1) {cout << "Warning !! Other bodyguard is already existed in there !! " << endl;
				return false;}}
		if (b == "7") {if (body_counter[6] == 1) {cout << "Warning !! Other bodyguard is already existed in there !! " << endl;
				return false;}}
		if (b == "8") {if (body_counter[7] == 1) {cout << "Warning !! Other bodyguard is already existed in there !! " << endl;
				return false;}}
		if (b == "9") {if (body_counter[8] == 1) {cout << "Warning !! Other bodyguard is already existed in there !! " << endl;
				return false;}}
		if (b == "10") {if (body_counter[9] == 1) {cout << "Warning !! other bodyguard is already existed in there !! " << endl;
				return false;}}
	return true;
}

/***********************************
 * Function: ant_maker_2
 * Description: generator part for ant by user input
 * Parameters: vector,vector,int,int,string,string 
 * Pre-Conditions: take 6 arguments as string, int ,vector
 * Post-Conditions: one ant is created 
***********************************/ 

void Ant::ant_maker_2(vector<Ant*> &ant_arr, vector<Ant*> &body_arr, int ant_counter[10], int body_counter[10], string& a, string& b){
	
	if (a == "1") {
		Harvester *harv = new Harvester;
		ant_arr[atoi(b.c_str()) - 1] = harv;
		ant_counter[atoi(b.c_str()) - 1] = 1;
	}
	if (a == "2") {
		Thrower *thr = new Thrower;
		ant_arr[atoi(b.c_str()) - 1] = thr;
		ant_counter[atoi(b.c_str()) - 1] = 1;
	}
	if (a == "3") {
		Fire *fir = new Fire;
		ant_arr[atoi(b.c_str()) - 1] = fir;
		ant_counter[atoi(b.c_str()) - 1] = 1;
	}
	if (a == "4") {
		Long_thrower *Lthr = new Long_thrower;
		ant_arr[atoi(b.c_str()) - 1] = Lthr;
		ant_counter[atoi(b.c_str()) - 1] = 1;
	}

}

/***********************************
 * Function: ant_maker_3
 * Description: generator part for ant by user input
 * Parameters: vector,vector,int,int,string,string 
 * Pre-Conditions: take 6 arguments as string, int ,vector
 * Post-Conditions: one ant is created 
***********************************/ 
void Ant::ant_maker_3(vector<Ant*> &ant_arr, vector<Ant*> &body_arr, int ant_counter[10], int body_counter[10], string& a, string& b) {

	if (a == "5") {
		Short_thrower *Sthr = new Short_thrower;
		ant_arr[atoi(b.c_str()) - 1] = Sthr;
		ant_counter[atoi(b.c_str()) - 1] = 1;
	}
	if (a == "6") {
		Wall *wal = new Wall;
		ant_arr[atoi(b.c_str()) - 1] = wal;
		ant_counter[atoi(b.c_str()) - 1] = 1;
	}
	if (a == "7") {
		Ninja *nin = new Ninja;
		ant_arr[atoi(b.c_str()) - 1] = nin;
		ant_counter[atoi(b.c_str()) - 1] = 2;
	}
	if (a == "8") {
		Bodyguard *bg = new Bodyguard;
		body_arr[atoi(b.c_str()) - 1] = bg;
		body_counter[atoi(b.c_str()) - 1] = 1;
	}

}

/***********************************
 * Function: ant_maker
 * Description: generator part for ant by user input
 * Parameters: insect,vector,vector,int,int
 * Pre-Conditions: take 5 arguments as object, int ,vector
 * Post-Conditions: one ant is created 
***********************************/ 
void Ant::ant_maker(Insect& game, vector<Ant*> &ant_arr, vector<Ant*> &body_arr, int ant_counter[10], int body_counter[10]) {
	string a,b;
	int food = game.get_food();
	cout << "Player's food amount : " << game.get_food() << endl;
	game.menu_prompt();
	cin >> a;
	while (num_check(a) == false || food_check(a,food) == false) {
		game.menu_prompt();
		cin >> a;
	}
	take_food(game, a);
	//location
	cout << "where do you want to send the new ant? (2~10)" << endl;
	cin >> b;
	if (a == "8") {while (location_check(b) == false || body_empty_check(body_counter, b) == false) { cin >> b; }
	}
	else { while (location_check(b) == false || empty_check(ant_counter, b) == false) { cin >> b; } }
	ant_maker_2(ant_arr, body_arr, ant_counter, body_counter, a, b);
	ant_maker_3(ant_arr, body_arr, ant_counter, body_counter, a, b);
	

}

/***********************************
 * Function: board_stat
 * Description: print board situation from the game
 * Parameters: insect,vector,vector,int,int 
 * Pre-Conditions: take 5 arguments as object, int ,vector
 * Post-Conditions: print ant's situation 
***********************************/ 
void Ant::board_stat(Insect& game, vector<Ant*> &ant_arr, vector<Ant*> &body_arr, int ant_counter[10], int body_counter[10]) {
	cout << "Ant's status on the battle ground " << endl;
	cout << "---------------------------------" << endl;
	cout << "Square 1 : Queen" << endl;
	if (ant_counter[1] == 1 || ant_counter[1] == 2) {
		cout << "Square 2 : " << ant_arr[1]->get_position() << endl;
		cout << "Armor : " << ant_arr[1]->get_armor() << endl;
	}
	if (body_counter[1] == 1) {
		cout << "Square 2 : " << body_arr[1]->get_position() << endl;
		cout << "Armor : " << body_arr[1]->get_armor() << endl;
	}
	if (ant_counter[2] == 1 || ant_counter[2] ==2) {
		cout << "Square 3 : " << ant_arr[2]->get_position() << endl;
		cout << "Armor : " << ant_arr[2]->get_armor() << endl;
	}
	if (body_counter[2] == 1) {
		cout << "Square 3 : " << body_arr[2]->get_position() << endl;
		cout << "Armor : " << body_arr[2]->get_armor() << endl;
	}
	if (ant_counter[3] == 1 || ant_counter[3] == 2) {
		cout << "Square 4 : " << ant_arr[3]->get_position() << endl;
		cout << "Armor : " << ant_arr[3]->get_armor() << endl;
	}
	if (body_counter[3] == 1) {
		cout << "Square 4 : " << body_arr[3]->get_position() << endl;
		cout << "Armor : " << body_arr[3]->get_armor() << endl;
	}

}

/***********************************
 * Function: board_stat_2
 * Description: print board situation from the game
 * Parameters: insect,vector,vector,int,int 
 * Pre-Conditions: take 5 arguments as object, int ,vector
 * Post-Conditions: print ant's situation 
***********************************/ 
void Ant::board_stat_2(Insect& game, vector<Ant*> &ant_arr, vector<Ant*> &body_arr, int ant_counter[10], int body_counter[10]) {
	if (ant_counter[4] == 1 || ant_counter[4] == 2) {cout << "Square 5 : " << ant_arr[4]->get_position() << endl;
		cout << "Armor : " << ant_arr[4]->get_armor() << endl;}
	if (body_counter[4] == 1) {cout << "Square 5 : " << body_arr[4]->get_position() << endl;
		cout << "Armor : " << body_arr[4]->get_armor() << endl;}
	if (ant_counter[5] == 1 || ant_counter[5] ==2) {cout << "Square 6 : " << ant_arr[5]->get_position() << endl;
		cout << "Armor : " << ant_arr[5]->get_armor() << endl;}
	if (body_counter[5] == 1) {cout << "Square 6 : " << body_arr[5]->get_position() << endl;
		cout << "Armor : " << body_arr[5]->get_armor() << endl;}
	if (ant_counter[6] == 1 || ant_counter[6] == 2) {cout << "Square 7 : " << ant_arr[6]->get_position() << endl;
		cout << "Armor : " << ant_arr[6]->get_armor() << endl;}
	if (body_counter[6] == 1) {cout << "Square 7 : " << body_arr[6]->get_position() << endl;
		cout << "Armor : " << body_arr[6]->get_armor() << endl;}
	if (ant_counter[7] == 1 || ant_counter[7] == 2) {cout << "Square 8 : " << ant_arr[7]->get_position() << endl;
		cout << "Armor : " << ant_arr[7]->get_armor() << endl;}
	if (body_counter[7] == 1) {cout << "Square 8 : " << body_arr[7]->get_position() << endl;
		cout << "Armor : " << body_arr[7]->get_armor() << endl;}
	if (ant_counter[8] == 1 || ant_counter[8] == 2) {cout << "Square 9 : " << ant_arr[8]->get_position() << endl;
		cout << "Armor : " << ant_arr[8]->get_armor() << endl;}
	if (body_counter[8] == 1) {cout << "Square 9 : " << body_arr[8]->get_position() << endl;
		cout << "Armor : " << body_arr[8]->get_armor() << endl;}
	if (ant_counter[9] == 1 || ant_counter[9] == 2) {cout << "Square 10 : " << ant_arr[9]->get_position() << endl;
		cout << "Armor : " << ant_arr[9]->get_armor() << endl;}
	if (body_counter[9] == 1) {cout << "Square 10 : " << body_arr[9]->get_position() << endl;
		cout << "Armor : " << body_arr[9]->get_armor() << endl;}
}

/***********************************
 * Function: ant_attack
 * Description: activate attacker's abilities
 * Parameters: insect,vector,Bee,int,int 
 * Pre-Conditions: take 5 arguments as object, int ,vector
 * Post-Conditions: changed bee's armor or killed 
***********************************/ 
void Ant::ant_attack(Insect& game, vector<Ant*> &ant_arr, Bee bee_arr[][10], int ant_counter[10], int bee_counter[][10]) {
	for (int i = 1; i < 10; i++) {
		if (ant_counter[i] == 1 || ant_counter[i] == 2) {
			ant_arr[i]->ability(game, ant_arr, bee_arr,ant_counter, bee_counter, i);
		}
	}
}

/***********************************
 * Function: bee_move_attack
 * Description: activate bee's attack or move
 * Parameters: vector,vector,Bee,int,int,int 
 * Pre-Conditions: take 6 arguments as object, int ,vector
 * Post-Conditions: changed ant's armor or killed 
***********************************/ 
void Ant::bee_move_attack(vector<Ant*> &ant_arr, vector<Ant*> &body_arr, Bee bee_arr[][10], int ant_counter[10], int body_counter[10], int bee_counter[][10]) {
	for (int i = 0; i < 10; i++) {
		for (int j = 0; j < 20; j++) {
			if (bee_counter[j][i] == 1){
				if ((ant_counter[i] == 0 && body_counter[i] == 0) || ant_counter[i] == 2) {
					int a = 0;
					while (bee_counter[a][i - 1] != 0) {
						a = a + 1;
					}
					Bee temp;
					temp = bee_arr[a][i - 1];
					bee_arr[a][i - 1] = bee_arr[j][i];
					bee_arr[j][i] = temp;
					bee_counter[j][i] = 0;
					bee_counter[a][i - 1] = 1;
					cout << "Bee is moving !!   from Battle ground " << i+1 << " to Battle ground " << i << endl;
				}
				if (ant_counter[i] == 1 || body_counter[i] == 1) {
					cout << "Bee's sting attack on battle ground " << i + 1 << endl;
					if (body_counter[i] == 1) {
						body_arr[i]->set_armor(body_arr[i]->get_armor() - 1);
					}
					else { ant_arr[i]->set_armor(ant_arr[i]->get_armor() - 1); }
				}
			}
			
		}
	}
}

/***********************************
 * Function: ant_dead
 * Description: check ant's armor and claim dead ant
 * Parameters: insect,vector,int,int 
 * Pre-Conditions: take 4 arguments as int ,vector
 * Post-Conditions: changed ant's situation 
***********************************/ 
void Ant::ant_dead(vector<Ant*> &ant_arr, vector<Ant*> &body_arr, int ant_counter[10], int body_counter[10]) {
	for (int i = 0; i < 10; i++) {
		if (ant_counter[i] == 1) {
			if (ant_arr[i]->get_armor() <= 0 && ant_arr[i]->get_position() != "Fire") {
				ant_arr[i]->rip_ant();
				delete ant_arr[i];
				ant_arr[i] = NULL;
				ant_counter[i] = 0;
			}
		}
		if (body_counter[i] == 1) {
			if (body_arr[i]->get_armor() <= 0) {
				body_arr[i]->rip_ant();
				delete body_arr[i];
				body_arr[i] = NULL;
				body_counter[i] = 0;
			}
		}
	}
}

/***********************************
 * Function: ant_clean
 * Description: cleaning memory after game end
 * Parameters: vector,vector,int,int 
 * Pre-Conditions: take 4 arguments as int ,vector
 * Post-Conditions: no memory leak 
***********************************/ 
void Ant::ant_clean(vector<Ant*> &ant_arr, vector<Ant*> &body_arr, int ant_counter[10], int body_counter[10]) {
	for (int i = 0; i < 10; i++) {
		if (ant_counter[i] == 1 || ant_counter[i] == 2) {
			delete ant_arr[i];
		}
		if (body_counter[i] == 1) {
			delete body_arr[i];
		}
	}
}



