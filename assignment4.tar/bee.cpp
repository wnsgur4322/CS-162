/***************************************************
 * Program filename: bee.cpp
 * Author: Junhyeok Jeong
 * Date:5/27/2018
 * Description: header file part for property class
 * Input: function's parameters and definitions
 * Output: x
****************************************************/

#include <iostream>
#include <cstdlib>
#include <stdio.h>
#include <string>
#include <vector>
#include "bee.h"

using namespace std;

//constructor
Bee::Bee() {
	attack = 0;
	armor = 0;
	bee_num = 0;
	status = "";
}

Bee::Bee(int at, int ar, int b_n,string st) {
attack = at;
armor = ar;
bee_num = b_n;
status = st;
}

//accessor
int Bee::get_attack() const { return attack; }
int Bee::get_armor() const { return armor; }
int Bee::get_bee_num() const { return bee_num; }
string Bee::get_status() const { return status; }

//mutator
void Bee::set_attack(int at) { attack = at; }
void Bee::set_armor(int ar) { armor = ar; }
void Bee::set_bee_num(int bn) { bee_num = bn; }
void Bee::set_status(string st) { status = st; }

//copy constructor
Bee::Bee(const Bee& copy) {
	attack = copy.attack;
	armor = copy.armor;
	bee_num = copy.bee_num;
	status = copy.status;

}


//assignment operator overload
const Bee& Bee::operator=(const Bee& copy) {
		attack = copy.attack;
		armor = copy.armor;
		bee_num = copy.bee_num;
		status = copy.status;

}

//destructor
Bee::~Bee(){}


/***********************************
 * Function: sum_bee
 * Description: calculating the number of bee
 * Parameters: int
 * Pre-Conditions: take 1 argument as  int array
 * Post-Conditions: return the number of bee
***********************************/ 
int Bee::sum_bee(int bee_counter[][10]) {
	int sum=0;
	for (int i = 0; i < 20; i++) {
		for (int j = 0; j < 10; j++) {
			sum = sum + bee_counter[i][j];
		}
	}
	return sum;
}

/***********************************
 * Function: bee_maker
 * Description: generator of bee
 * Parameters:Bee, int, int
 * Pre-Conditions: take 3 arguments as object,  int array
 * Post-Conditions: bee is created
***********************************/ 


void Bee::bee_maker(Bee bee_arr[][10],int bee_counter[][10], int& turn_counter) {
	cout << "bee is coming ! " << endl;
	int i = 0;
	Bee buzz=Bee(1, 3, turn_counter,"live");
	while(bee_counter[i][9] != 0 ) {
		i = i + 1;
	}

	bee_arr[i][9] = buzz;
	bee_counter[i][9] = 1;
}

/***********************************
 * Function: bee_stat
 * Description: print bee's situation
 * Parameters: Bee, int
 * Pre-Conditions: take 2 argument as object or  int array
 * Post-Conditions: return board of bee
***********************************/ 

void Bee::bee_stat(Bee bee_arr[][10], int bee_counter[][10]) {
	cout << "Bee's status on the battle ground " << endl;
	cout << "---------------------------------" << endl;
	for (int i = 0; i < 10; i++) {
		cout << "Sqaure " << i + 1 << endl;
		for (int j = 0; j < 20; j++) {
			if (bee_counter[j][i] == 1) {
				cout << "Bee No. " << bee_arr[j][i].get_bee_num() << endl;
				cout << "Armor : " << bee_arr[j][i].get_armor() << endl;
			}
		}
		cout << "----------------------------------" << endl;
	}
}

/***********************************
 * Function: bee_rip
 * Description: claim dead bees
 * Parameters:Bee, int
 * Pre-Conditions: take 2 arguments as object, int array
 * Post-Conditions: changed bee array by dead bee
***********************************/ 

void Bee::bee_rip(Bee bee_arr[][10], int bee_counter[][10]) {
	for (int i = 0; i < 10; i++) {
		for (int j = 0; j < 20; j++) {
			if (bee_counter[j][i] == 1) {
				if (bee_arr[j][i].get_armor() <= 0) {
					cout << "No." << bee_arr[j][i].get_bee_num() << " is dead R.I.P" << endl;
					bee_counter[j][i] = 0;
					Bee dead = Bee(0, 0, 0, "dead");
					bee_arr[j][i] = dead;
				}
			}
		}
	}
}

/***********************************
 * Function: win_game
 * Description: bool checking for win
 * Parameters: Bee, int
 * Pre-Conditions: take 2 arguments as object, int array
 * Post-Conditions: return bool value
***********************************/ 

bool Bee::win_game(Bee bee_arr[][10],int bee_counter[][10]) {
	if (bee_arr[20][10].sum_bee(bee_counter) == 0) {
		return true;
	}
	return false;
}

/***********************************
 * Function: lose_game
 * Description: bool checking for win
 * Parameters: Bee, int
 * Pre-Conditions: take 2 arguments as object, int array
 * Post-Conditions: return bool value
***********************************/ 

bool Bee::lose_game(Bee bee_arr[][10], int bee_counter[][10]) {
	for (int i = 0; i < 20; i++) {
		if (bee_counter[i][0] >= 1) {
			return true;
		}
	}
	return false;
}


