/***************************************************
 * Program filename: bee.h
 * Author: Junhyeok Jeong
 * Date:5/27/2018
 * Description: header file part for property class
 * Input: function's prototypes
 * Output: x
****************************************************/

#include <iostream>
#include <cstdlib>
#include <string>
#include <stdio.h>
#include <vector>
#ifndef BEE_H
#define BEE_H
#include "insect.h"

class Bee {
private:
	int attack;
	int armor;
	int bee_num;
	string status;
	
public:
	Bee();
	Bee(int, int, int,string);

	int get_attack() const;
	int get_armor() const;
	int get_bee_num() const;
	string get_status() const;

	void set_attack(int);
	void set_armor(int);
	void set_bee_num(int);
	void set_status(string);

	//copy constructor
	Bee(const Bee&);
	//assignment operator overload
	const Bee& operator=(const Bee &);
	//destructor
	~Bee();
	int sum_bee(int[][10]);
	void bee_maker(Bee [][10], int [][10], int &);
	void bee_stat(Bee[][10], int[][10]);
	void bee_rip(Bee[][10], int[][10]);

	bool win_game(Bee[][10], int[][10]);
	bool lose_game(Bee[][10], int[][10]);
};
#endif

