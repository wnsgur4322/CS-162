/***************************************************
 * Program filename: ant.h
 * Author: Junhyeok Jeong
 * Date:5/27/2018
 * Description: header file part for property class
 * Input: function's prototypes
 * Output: x
****************************************************/

#include <iostream>
#include <cstdlib>
#include <string>
#include <vector>
#ifndef ANT_H
#define ANT_H
#include "insect.h"
#include "bee.h"

using namespace std;

class Ant {
protected:
	int armor;
	int food_cost;
	string position;
	friend class Insect;
public:
	
	Ant();
	Ant(int, int, string);
	Ant(const Ant&);
	const Ant& operator=(const Ant &);

	void set_armor(int);
	void set_food_cost(int);
	void set_position(string);
	
	int get_armor() const;
	int get_food_cost() const;
	string get_position() const;

	~Ant();
	
	virtual void rip_ant();
	virtual void ability(Insect &, vector<Ant*> &, Bee[][10], int[10], int[][10], int);
	bool num_check(string &);
	bool food_check(string &, int &);
	bool location_check(string &);
	bool empty_check(int[], string &);
	bool body_empty_check(int[], string &);
	void take_food(Insect &, string &);
	
	void extend_arr(vector<Ant*> &);
	void ant_maker_2(vector<Ant*> &, vector<Ant*> &, int[], int[], string &, string &);
	void ant_maker_3(vector<Ant*> &, vector<Ant*> &, int[], int[], string &, string &);
	void ant_maker(Insect &, vector<Ant*> &, vector<Ant*> &, int[], int[]);
	void board_stat(Insect &, vector<Ant*> &, vector<Ant*> &, int[], int[]);
	void board_stat_2(Insect &, vector<Ant*> &, vector<Ant*> &, int[], int[]);
	void ant_attack(Insect&, vector<Ant*> &, Bee[][10], int[10], int[][10]);
	void bee_move_attack(vector<Ant*> &, vector<Ant*> &, Bee[][10], int[10], int[10], int[][10]);
	void ant_dead(vector<Ant*> &, vector<Ant*> &, int[], int[]);
	void ant_clean(vector<Ant*> &, vector<Ant*> &, int[], int[]);
};

class Harvester : public Ant {
protected:

public:
	Harvester();
	Harvester(int, int, string);
	Harvester(const Harvester&);
	const Harvester& operator=(const Harvester &);
	~Harvester();

	int harvest();
	void rip_ant();
	void ability(Insect &, vector<Ant*> &, Bee[][10], int [10], int [][10], int);

};

class Thrower : public Ant {
protected:
	int attack;
public:
	Thrower();
	Thrower(int,int, int, string);
	Thrower(const Thrower&);
	const Thrower& operator=(const Thrower &);
	~Thrower();

	void ability(Insect &, vector<Ant*> &, Bee[][10], int[10], int[][10], int);
	bool check_range();
	void rip_ant();

};

class Fire : public Ant {
protected:

public:
	Fire();
	Fire(int, int, string);
	Fire(const Fire&);
	const Fire& operator=(const Fire &);
	~Fire();

	void ability(Insect &, vector<Ant*> &, Bee[][10], int[10], int[][10], int);
	void rip_ant();

};

class Long_thrower : public Ant {
protected:
	int attack;

public:
	Long_thrower();
	Long_thrower(int, int,int, string);
	Long_thrower(const Long_thrower&);
	const Long_thrower& operator=(const Long_thrower &);
	~Long_thrower();

	void ability(Insect &, vector<Ant*> &, Bee[][10], int[10], int[][10], int);
	void rip_ant();

};

class Short_thrower : public Ant {
protected:
	int attack;

public:
	Short_thrower();
	Short_thrower(int, int, int, string);
	Short_thrower(const Short_thrower&);
	const Short_thrower& operator=(const Short_thrower &);
	~Short_thrower();

	void ability(Insect &, vector<Ant*> &, Bee[][10], int[10], int[][10], int);
	void rip_ant();

};

class Wall : public Ant {
protected:

public:
	Wall();
	Wall(int, int, string);
	Wall(const Wall&);
	const Wall& operator=(const Wall &);
	~Wall();

	void rip_ant();


};

class Ninja : public Ant {
protected:
	int attack;

public:
	Ninja();
	Ninja(int, int, string);
	Ninja(const Ninja&);
	const Ninja& operator=(const Ninja &);
	~Ninja();

	void ability(Insect &, vector<Ant*> &, Bee[][10], int[10], int[][10], int);
	void rip_ant();


};

class Bodyguard : public Ant {
protected:

public:
	Bodyguard();
	//Bodyguard(int, int, string);
	//Bodyguard(const Bodyguard&);
	//const Bodyguard& operator=(const Bodyguard &);
	~Bodyguard();

	void rip_ant();
};


#endif


