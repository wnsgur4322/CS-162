/***************************************************
 * Program filename: menu.h
 * Author: Junhyeok Jeong
 * Date:4/29/2018
 * Description: header file for menu and connected with pizza.h
 * Input: proto types of objects and functions in menu class
 * Output: x
****************************************************/

#include <iostream>
#include <fstream>
#include <string>
#include <cstdlib>
#include "pizza.h"

using namespace std;

class Menu{
	private:
		int num_pizzas;
		Pizza* pizzas;
	public:
		Menu search_pizza_by_cost(int upper_bound, string size);
		Menu search_pizza_by_ingredients_to_include(string* ingredients, int num_ingredients);
		Menu search_pizza_by_ingredients_to_exclude(string* ingredients, int num_ingredients);
		void add_to_menu(Pizza pizza_to_add);
		void remove_from_menu(int index_of_pizza_on_menu);
};


