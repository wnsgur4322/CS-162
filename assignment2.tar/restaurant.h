/***************************************************
 * Program filename: restaurant.h
 * Author: Junhyeok Jeong
 * Date:4/29/2018
 * Description: header file for restaurant and this header is the main program
 * Input: proto types of objects and functions in restaurant class
 * Output: x
****************************************************/
#include <iostream>
#include <fstream>
#include <string>
#include <cstdlib>
#include "menu.h"
#include "emp.h"
#ifndef RESTAURANT_H
#define RESTAURANT_H

using namespace std;

class Restaurant {
	private:
		Menu menu;
		employee* employees;
		hours* week;
		string name;
		string phone;
		string address;
	public:
		void set_employees(string*, int&);
		void set_week(string*, int, int&);
		void set_name(string);
		void set_phone(string);
		void set_address(string);

		employee* get_employees();
		string get_employee_id(int) const;
		string get_employee_first_name(int) const;
		string get_employee_last_name(int) const;
		string get_employee_password(int) const;
		
		hours* get_week();
		string get_hours_day(int) const;
		string get_hours_open_hour(int) const;
		string get_hours_close_hour(int) const;

		string get_name();
		string get_phone();
		string get_address();
		
		Restaurant();
		Restaurant(string, string, string);
		~Restaurant();
		Restaurant(const Restaurant& copy);
		
		void load_data(Restaurant[]);
		bool login(string id, string password);
		void view_menu();
		void view_hours();
		void view_address();
		void view_phone();
		void search_menu_by_price();
		void search_by_ingredients();
		void place_order(Pizza* selection);
		void change_hours();
		void add_to_menu();
		void remove_from_menu();
		void view_orders();
		void remove_orders();
			
		const Restaurant& operator=(const Restaurant &);
};
#endif
