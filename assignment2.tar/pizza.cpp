/***************************************************
 * Program filename: pizza.cpp
 * Author: Junhyeok Jeong
 * Date:4/29/2018
 * Description: cpp file for functions and proto types connected with pizza.h
 * Input: proto types of objects and functions in pizza class and variables
 * Output: x
****************************************************/
#include <iostream>
#include <fstream>
#include <string>
#include <cstdlib>
#include "pizza.h"

using namespace std;

//constructor
Pizza::Pizza(){
	name ="";
	small_cost=0;
	medium_cost=0;
	large_cost=0;
	num_ingredients=0;
	ingredients=NULL;
}

Pizza::~Pizza(){
	if(ingredients){
		delete [] ingredients;
}
}


//accessor
	string Pizza::get_name() const {return name;}
	int Pizza::get_small_cost() const {return small_cost;}
	int Pizza::get_medium_cost() const {return medium_cost;}
	int Pizza::get_large_cost() const {return large_cost;}
	int Pizza::get_num_ingredients() const {return num_ingredients;}
	string* Pizza::get_ingredients() {return ingredients;}

//mutator
	void Pizza::set_name(string nm) {name= nm;}
	void Pizza::set_small_cost(int sc) {small_cost= sc;}
	void Pizza::set_medium_cost(int mc) {medium_cost= mc;}
	void Pizza::set_large_cost(int lc) {large_cost=lc;}
	void Pizza::set_num_ingredients(int ing_num) {num_ingredients= ing_num;}
	void Pizza::set_ingredients(string* tp){
		int size= get_num_ingredients();
		ingredients = new string[size];
		string input;
		
		for(int i=0; i<size; i++){
			ingredients[i] = tp[i+5];
}
}  

	

