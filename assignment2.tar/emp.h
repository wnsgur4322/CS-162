/***************************************************
 * Program filename: emp.h
 * Author: Junhyeok Jeong
 * Date:4/29/2018
 * Description: header file for employee struct and hours struct
 * Input: proto types of objects in employee and hours struct
 * Output: x
****************************************************/
#include <iostream>
#include <fstream>
#include <cstdlib>
#include <string>
#ifndef EMPLOYEE_H
#ifndef HOURS_H
#define EMPLOYEE_H
#define HOURS_H

using namespace std;

struct employee {
	string id;
	string first_name;
	string last_name;
	string password;
};

struct hours{
	string day;
	string open_hour;
	string close_hour;
};

#endif
#endif
