/***************************************************
 * Program filename: restaurant.cpp
 * Author: Junhyeok Jeong
 * Date:4/29/2018
 * Description: cpp file for functions and proto types connected with restaurant.h
 * Input: proto types of objects and functions in restaurant class and variables
 * Output: x
****************************************************/
#include <iostream>
#include <fstream>
#include <string>
#include "restaurant.h"
#include <cstdlib>

using namespace std;

Restaurant::Restaurant(){

	employees = NULL;
	week = NULL;
	name ="";
	phone ="";
	address="";
}

Restaurant::Restaurant(string nm, string ph, string ad){

	name=nm;
	phone=ph;
	address=ad;
}
Restaurant::~Restaurant(){
	if(employees){
		delete [] employees;}

	if(week){
		delete [] week;}

}

employee* Restaurant::get_employees() {return employees;}
string Restaurant::get_employee_id(int index) const {return employees[index].id;}
string Restaurant::get_employee_first_name(int index) const {return employees[index].first_name;}
string Restaurant::get_employee_last_name(int index) const {return employees[index].last_name;}
string Restaurant::get_employee_password(int index) const {return employees[index].password;}

hours* Restaurant::get_week() {return week;}
string Restaurant::get_hours_day(int index) const {return week[index].day;}
string Restaurant::get_hours_open_hour(int index) const {return week[index].open_hour;}
string Restaurant::get_hours_close_hour(int index) const {return week[index].close_hour;}
string Restaurant::get_name(){return name;}
string Restaurant::get_phone(){return phone;}
string Restaurant::get_address(){return address;}

/***********************************
 * Function: set_employees
 * Description: mutator for employees information
 * Parameters:string* tp, int& count
 * Pre-Conditions: take 2 argument as string array and integer
 * Post-Conditions: read employee's information form text file
***********************************/ 
void Restaurant::set_employees(string* tp, int& count){

		employees = new employee[4];
	
			employees[count].id = tp[0];
			employees[count].first_name = tp[1];
			employees[count].last_name = tp[2];
			employees[count].password = tp[3];

		

}
/***********************************
 * Function: set_week
 * Description: mutator for hours information
 * Parameters:string* tp, int& i, int open_days
 * Pre-Conditions: take 3 arguments as string array and integer
 * Post-Conditions: read restaurant's information form text file
***********************************/ 

void Restaurant::set_week(string* tp, int open_days,int& i){

		week = new hours[open_days];
			
			week[i].day = tp[0];
			week[i].open_hour = tp[1];
			week[i].close_hour = tp[2];
}
void Restaurant::set_name(string s){name = s;}
void Restaurant::set_phone(string s){phone = s;}
void Restaurant::set_address(string s){address = s;}

/***********************************
 * Function: Restaurant copy function
 * Description: copy function for assignment operator overload
 * Parameters:const Restaurant& copy
 * Pre-Conditions: take 1 argument as a costant
 * Post-Conditions: copy objects form right side
***********************************/ 

Restaurant::Restaurant(const Restaurant& copy){

	name =copy.name;
	phone =copy.phone;
	address=copy.address;

}

/***********************************
 * Function: operator=
 * Description: assignment operator overload
 * Parameters:const Restaurant& copy
 * Pre-Conditions: take 1 argument as constant value
 * Post-Conditions: copy function is worked
***********************************/ 
const Restaurant& Restaurant::operator=(const Restaurant& copy){

		name=copy.name;
		phone=copy.phone;
		address=copy.address;
		
		if(employees != NULL){
			delete [] employees;}
		else{
			employees = new employee[4];
			for(int i=0; i<4; i++){
				employees[i] = copy.employees[i];}
}
	return *this;
}





