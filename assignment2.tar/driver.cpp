/***************************************************
 * Program filename: dirver.cpp
 * Author: Junhyeok Jeong
 * Date:4/29/2018
 * Description: cpp file for functions and proto types connected with restaurant.h
 * Input: functions in variables
 * Output: pizza program
****************************************************/
#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cstdlib>
#include "restaurant.h"

/***********************************
 * Function: StringSplit
 * Description: take a string and then slice by " " 
 * Parameters:string strTarget, string strTok, int num
 * Pre-Conditions: take 3 arguments as string and integer
 * Post-Conditions: return sliced string as a dynamic array
***********************************/ 

string* StringSplit(string strTarget, string strTok, int num){
	int nCutPos;
	int nindex=0;
	string* strResult = new string[num+1];
	
	while((nCutPos =strTarget.find_first_of(strTok)) != strTarget.npos){
		if(nCutPos >0){
			strResult[nindex++] = strTarget.substr(0, nCutPos);}
		strTarget = strTarget.substr(nCutPos +1);}

	if(strTarget.length() >0){
		strResult[nindex++] = strTarget.substr(0,nCutPos);}

	return strResult;
}
/***********************************
 * Function: space_counter
 * Description: count white space
 * Parameters:string line
 * Pre-Conditions: take 1 argument as string
 * Post-Conditions: return the number of white spaces
***********************************/ 

int space_counter(string line){
	int counter=0;

	for(int i=0; i<line.length(); i++){
		if(line[i] ==' '){
			counter= counter+1;}
}
	return counter;
}
/***********************************
 * Function: main_counter
 * Description: count the number of pizza
 * Parameters: x
 * Pre-Conditions: take 1 argument as string
 * Post-Conditions: return the number of menu
***********************************/ 

int menu_counter(){
	ifstream rf;
	rf.open("menu.txt");
	int count=0;
	string line;
	while(!rf.eof()){
		count++;
		getline(rf,line);
		if(line==""){
			break;}
}
		rf.close();
	return count-1;
}

/***********************************
 * Function: pop_from_file
 * Description: read text file and then store the values in class objects
 * Parameters:Pizza p[], int num
 * Pre-Conditions: take 2 arguments as class, integer
 * Post-Conditions: mutated objects and stored
***********************************/ 

void pop_from_file(Pizza p[], int num){
	ifstream rf;
	string name,s;
	int s_cost=0, m_cost=0, l_cost=0, ing_num=0, count=0;
	
	rf.open("menu.txt");

	while(!rf.eof()){
		getline(rf,s);
		
		string *tp = StringSplit(s, " ",space_counter(s));
		
		/*for(int i=0; i<space_counter(s)+1; i++){
		cout << tp[i] << endl;}*/
		
		p[count].set_name(tp[0]);
		p[count].set_small_cost(atoi(tp[1].c_str()));
		p[count].set_medium_cost(atoi(tp[2].c_str()));
		p[count].set_large_cost(atoi(tp[3].c_str()));
		p[count].set_num_ingredients(atoi(tp[4].c_str()));
		p[count++].set_ingredients(tp);
		delete [] tp;
		if(count ==menu_counter())
			return;
}
	rf.close();
}
/***********************************
 * Function: pop_from_file_2
 * Description: read text file and then store the values in class objects
 * Parameters:Restaurant employees[]
 * Pre-Conditions: take 1 argument as class
 * Post-Conditions: mutated objects and stored
***********************************/ 

void pop_from_file_2(Restaurant employees[]){
	
	ifstream rf;
	string name,s;
	int count=0;
	
	rf.open("employee.txt");

	while(!rf.eof()){
		getline(rf,s);
		//cout << s << endl;	
		string *tp = StringSplit(s, " ",space_counter(s));
		
		/*for(int i=0; i<space_counter(s)+1; i++){
		cout << tp[i] << endl;}*/
		
		employees[count].set_employees(tp,count);

		count=count+1;
		
		delete [] tp;
		if(count == 3)
			return;
}
	rf.close();
}
/***********************************
 * Function: pop_from_file_3
 * Description: read text file and then store the values in class objects
 * Parameters:Restaurant r[]
 * Pre-Conditions: take 1 argument as class
 * Post-Conditions: mutated objects and stored
***********************************/ 

void pop_from_file_3(Restaurant r[]){
	ifstream rf;
	string name,s;
	
	rf.open("restaurant_info.txt");

	while(!rf.eof()){
		getline(rf,s);
		
		r->set_name(s);

		getline(rf,s);
		r->set_phone(s);

		getline(rf,s);
		r->set_address(s);

		getline(rf,s);
		int open_days= atoi(s.c_str());
		for(int i=0; i<open_days; i++){
			getline(rf,s);
			string *tp = StringSplit(s, " ",space_counter(s));
			r[i].set_week(tp,open_days,i);
			
			delete [] tp;
}
	break;

}
	rf.close();
}

/***********************************
 * Function: print_pizza
 * Description: show object's values in class
 * Parameters:Pizza& p
 * Pre-Conditions: take 1 arguments as class
 * Post-Conditions: print values
***********************************/ 

void print_pizza(Pizza& p){
		cout << p.get_name() << endl;
		cout << "small cost: " << p.get_small_cost() << endl;
		cout << "medium cost: " << p.get_medium_cost() << endl;
		cout << "large cost: " << p.get_large_cost() << endl;
		cout << "the number of ingredients: " << p.get_num_ingredients() << endl;
		
		string* arr= p.get_ingredients();
		cout << "ingredients: " << endl;
		for(int i=0; i<p.get_num_ingredients(); i++){
			cout << arr[i] <<" ";}
		cout << endl;
		
}
/***********************************
 * Function: print
 * Description: show object's values in class
 * Parameters:Pizza p[], int num
 * Pre-Conditions: take 2 arguments as class and integer
 * Post-Conditions: print values
***********************************/ 
void print(Pizza p[], int num){
	for(int i=0; i<num; i++){
		print_pizza(p[i]);}
}

/***********************************
 * Function: view_address
 * Description: show object's values in class
 * Parameters: x
 * Pre-Conditions: pop form file_3 should be worked
 * Post-Conditions: print values as address
***********************************/ 
void view_address(){
	Restaurant ap[255];
	pop_from_file_3(ap);
	
	cout << "GORDON RAMSAY PIZZA ADDRESS" << endl;
	cout << ap->get_address() << endl;

}
/***********************************
 * Function: view_phone
 * Description: show object's values in class
 * Parameters: x
 * Pre-Conditions: pop form file_3 should be worked
 * Post-Conditions: print values as phone number
***********************************/ 

void view_phone(){
	Restaurant ph[255];
	pop_from_file_3(ph);
	
	cout << "GORDON RAMSAY PIZZA PHONE NUMBER" << endl;
	cout << ph->get_phone() << endl;
	cout << "DONT HESITATE TO CALL ! PIZZA QUALITY IS GUARANTEED BY GORDON RAMSAY !" << endl;

}	
/***********************************
 * Function: check_main_menu
 * Description: check input for error handling
 * Parameters: string& a
 * Pre-Conditions: take an argument as string 
 * Post-Conditions: return true or false
***********************************/ 

bool check_main_menu(string& a){

		if(a=="C"){
			return true;}
		if(a=="E"){
			return true;}
		if(a=="Q"){
			return true;}
	cout << "IT IS RAW ! CHECK YOUR INPUT !! " << endl;
	cout << "WRITE YOUR INPUT AGAIN: " << endl;
	return false;
}
/***********************************
 * Function: employee_counter
 * Description: count the number of employees
 * Parameters: x
 * Pre-Conditions: should be read text file
 * Post-Conditions: return the number of employee
***********************************/ 

int employee_counter(){
	ifstream rf;
	rf.open("employee.txt");
	int count=0;
	string line;
	while(!rf.eof()){
		count++;
		getline(rf,line);
}
		rf.close();
	return count-1;
}
/***********************************
 * Function: open_days_counter
 * Description: count the number of open days
 * Parameters: x
 * Pre-Conditions: should be read text file
 * Post-Conditions: return the number of open days
***********************************/ 

int open_days_counter(){
	ifstream rf;
	rf.open("restaurant_info.txt");
	int count=0, open_days=0;
	string line;
	while(!rf.eof()){
		getline(rf,line);
		count++;
		if(count==4){
			open_days=atoi(line.c_str());}
}
	rf.close();
	
	return open_days;
}
/***********************************
 * Function: id_check
 * Description: comparing the input values with employee objects
 * Parameters: Restaurant* arr, string& id, string& pass
 * Pre-Conditions: Take 3 arguments as calss, string
 * Post-Conditions: set result's value
***********************************/ 

void id_check(Restaurant* arr,string& id, string& pass){
	bool result=false;
	int counter=0;
	for(int i=0; i<employee_counter(); i++){
		if(id == (arr[i]).get_employee_id(i) ){
			result=true;
			counter=i;
			break;}
}
	while(result==false){
		cout << "IT IS RAW! CHECK YOUR ID !!" << endl;
		cout << "Please provide your ID Number: " << endl;
		cin >> id;
		for(int i=0; i<employee_counter(); i++){
		if(id == (arr[i]).get_employee_id(i) ){
			result=true;
			counter=i;
			break;}
}
}
	
	cout << "Please provide your password: " <<endl;
	cin >> pass;	
	string password = (arr[counter]).get_employee_password(counter);
	
	for(int i=0; i<employee_counter(); i++){
		if(pass != password){
			cout << "It IS RAW! CHECK YOUR PASSWORD !! " << endl;
			id_check(arr,id,pass);}
}
	cout << "Welcome " << (arr[counter]).get_employee_first_name(counter) << " " << (arr[counter]).get_employee_last_name(counter)  << endl;
}

/***********************************
 * Function: emp_menu_1
 * Description: print employee menu
 * Parameters: x
 * Pre-Conditions: no syntax error
 * Post-Conditions: print texts
***********************************/ 

void emp_menu_1(){
	cout << "what do you want to do? " << endl;
	cout << "1. Change hours " << endl;
	cout << "2. View Orders " << endl;
	cout << "3. Remove Order " << endl;
	cout << "4. Add Item to Menu " << endl;
	cout << "5. Remove Item from Menu " << endl;
	cout << "6. View Menu " << endl;
	cout << "7. View Hours" << endl;
	cout << "8. View Address" << endl;
	cout << "9. View Phone" << endl;
	cout << "10.Log out" << endl;
}

/***********************************
 * Function: check_answer
 * Description: check input for error handling
 * Parameters: string& answer
 * Pre-Conditions: take an argument as string 
 * Post-Conditions: return true or false
***********************************/ 
bool check_answer(string& answer){

	if(answer != "1" && answer != "2" && answer != "3" && answer != "4" && answer != "5" && answer != "6" && answer != "7" && answer != "8" && answer != "9" && answer != "10"){
		return false;}

	return true;
}

/***********************************
 * Function: view_hour
 * Description: show object's values in class
 * Parameters: Restaurant* rest
 * Pre-Conditions:  should be read objects in Restaurant
 * Post-Conditions: print values as hours
***********************************/ 

void view_hour(Restaurant* rest){
	cout << "Day open close " << endl;
	for(int i=0; i<open_days_counter(); i++){
	cout<< rest[i].get_hours_day(i) <<" " << rest[i].get_hours_open_hour(i) <<" " << rest[i].get_hours_close_hour(i) << endl;} 
 
}	

/***********************************
 * Function: view_hour_2
 * Description: show object's values in class
 * Parameters: x
 * Pre-Conditions: should be read text file for information
 * Post-Conditions: print values as hours
***********************************/ 

void view_hour_2(){
	int counter=0;
	string line;
	ifstream rf;

	rf.open("restaurant_info.txt");
	cout << "Day open close " << endl;

	while(!rf.eof()){
		getline(rf,line);
		counter++;
		if(counter>=5){
		cout << line << endl;}
		if(counter ==11){
		break;}
}
	rf.close();
}

/***********************************
 * Function: update_hour
 * Description: update the text file for changing objects
 * Parameters: string& a, string& b, string& c
 * Pre-Conditions: file in and out should be worked
 * Post-Conditions: changed the information
***********************************/ 
	
void update_hour(string& a, string& b, string& c){
	string line;
	ifstream rf;
	ofstream wf;
	rf.open("restaurant_info.txt");
	wf.open("temp.txt");
	while(!rf.eof()){
		getline(rf,line);
		string *tp = StringSplit(line, " ",space_counter(line));

		if(a == tp[0]){
			wf << a << " " << b << " " << c << endl;
			delete [] tp;
			continue;}
		wf << line << endl;
		delete [] tp;
}

	wf.close();
	rf.close();

	remove("restaurant_info.txt");
	rename("temp.txt", "restaurant_info.txt");
}

/***********************************
 * Function: check_a
 * Description: check input for error handling
 * Parameters: string& a
 * Pre-Conditions: take an argument as string 
 * Post-Conditions: return true or false
***********************************/ 

bool check_a(string& a){
	if(a != "S" && a != "M" && a != "T" && a != "W" && a != "R" && a != "F" && a != "SA"){
		cout << "IT IS RAW ! ! CHECK YOUR INPUT ! " << endl;
		cout << "Which day would you like to change the hours for?" << endl;
		return false;}

	return true;
}
/***********************************
 * Function: check_b
 * Description: check input for error handling
 * Parameters: string& b
 * Pre-Conditions: take an argument as string 
 * Post-Conditions: return true or false
***********************************/ 

bool check_b(string& b){
	if(b != "1" && b != "2" && b != "3" && b != "4" && b != "5" && b != "6" && b != "7" && b != "8" && b != "9" && b != "10" && b != "11" && b != "12" && b != "13" && b != "14" && b != "15" && b != "16" && b != "17" && b != "18" && b != "19" && b != "20" && b != "21" && b != "22" && b != "23" && b != "24") {
	cout << "IT IS RAW !! CHECK YOUR INPUT !! " << endl;
	cout << "What should the opening time be? " << endl;
	return false;}
	
	return true;
}

/***********************************
 * Function: check_c
 * Description: check input for error handling
 * Parameters: string& c
 * Pre-Conditions: take an argument as string 
 * Post-Conditions: return true or false
***********************************/ 

bool check_c(string& c){
	if(c != "1" && c != "2" && c != "3" && c != "4" && c != "5" && c != "6" && c != "7" && c != "8" && c != "9" && c != "10" && c != "11" && c != "12" && c != "13" && c != "14" && c != "15" && c != "16" && c != "17" && c != "18" && c != "19" && c != "20" && c != "21" && c != "22" && c != "23" && c != "24") {
	cout << "IT IS RAW !! CHECK YOUR INPUT !! " << endl;
	cout << "What should the closing time be? " << endl;
	return false;}
	
	return true;
}

/***********************************
 * Function: change_hour
 * Description: change hour function as an employee option
 * Parameters: Restaurant* rest
 * Pre-Conditions: each answers should be correct
 * Post-Conditions: channged information of the restaurant
***********************************/ 

void change_hour(Restaurant* rest){
	Restaurant hour[255];
	string a,b,c;
	cout << "Which day would you like to change the hours for?" << endl;
	cin >> a;
	while(check_a(a) == false){
		cin >> a;}
	cout << "What should the opening time be? " << endl;
	cin >> b;
	while(check_b(b) == false){
		cin >> b;}
	cout << "What should the closing time be? " << endl;
	cin >> c;
	while(check_c(c) == false){
		cin >>c;}
	update_hour(a,b,c);
	pop_from_file_3(hour);
	cout << "Here are the updated hours: " << endl;
	view_hour(hour); 
		
}

/***********************************
 * Function: view_menu
 * Description: show pizza menu
 * Parameters: x
 * Pre-Conditions:  should be read objects in pizza class
 * Post-Conditions: print values as pizza menu
***********************************/ 

void view_menu(){

	Pizza menu[menu_counter()];
	pop_from_file(menu,menu_counter());
	print(menu,menu_counter()); 
}

/***********************************
 * Function: order_counter
 * Description: count the number of orders
 * Parameters: x
 * Pre-Conditions: should be read text file
 * Post-Conditions: return the number of orders
***********************************/ 

int order_counter(){
	ifstream rf;
	rf.open("orders.txt");
	int count=0;
	string line;
	while(!rf.eof()){
		count++;
		getline(rf,line);
		if(line==""){
			break;}
}
		rf.close();
	return count-1;
}

/***********************************
 * Function: view_orders
 * Description: show orders 
 * Parameters: x
 * Pre-Conditions:  should be read text file
 * Post-Conditions: print values as orders
***********************************/ 

void view_orders(){
	string word;
	ifstream rf;
	rf.open("orders.txt");

	for(int i=0; i<order_counter(); i++){
		rf >> word;
		cout << "Order Number: "<< word << endl;
		rf >> word;
		cout << "Customer Name: " << word << endl;
		rf >> word;
		cout << "Customer CC: " << word << endl;
		rf >> word;
		cout << "Delievery Address: " << word << endl;
		rf >> word;
		cout << "Customer phone: " << word << endl;
		rf >> word;
		cout << "Pizza name: " << word << endl;
		rf >> word;
		cout << "Size: " << word << endl;
		rf >> word;
		cout << "Quantity: " << word << endl;
}
	rf.close();
}

/***********************************
 * Function: update_order
 * Description: update the text file for changing objects
 * Parameters: string& num
 * Pre-Conditions: take an argument as string
 * Post-Conditions: changed the information
***********************************/ 

void update_order(string& num){
	string line;
	ifstream rf;
	ofstream wf;
	rf.open("orders.txt");
	wf.open("temp.txt");
	while(!rf.eof()){
		getline(rf,line);
		string *tp = StringSplit(line, " ",space_counter(line));

		if(num != tp[0]){
			wf << line << endl;
			delete [] tp;
			continue;}
		delete [] tp;
}

	wf.close();
	rf.close();

	remove("orders.txt");
	rename("temp.txt", "orders.txt");
}

/***********************************
 * Function: remove_order
 * Description: remove order from the user
 * Parameters: x
 * Pre-Conditions: file in and out should be worked
 * Post-Conditions: changed the information
***********************************/ 

void remove_order(){
	string num;
	cout << "Which order number do you want to remove? " << endl;
	cin >> num;
	update_order(num);
	cout << "Here is the updated order list" << endl;
	view_orders();
}

/***********************************
 * Function: update_menu
 * Description: update the text file for changing objects
 * Parameters: string topping[], string& name, string& small, string& medium, string& large, string& num
 * Pre-Conditions: the information from class should be correct
 * Post-Conditions: changed the information
***********************************/ 

void update_menu(string topping[], string& name, string& small, string& medium, string& large, string& num){
	string line;
	ifstream rf;
	ofstream wf;
	rf.open("menu.txt");
	wf.open("temp.txt");
	for(int i=0; i<menu_counter(); i++){
		getline(rf,line);
		string *tp = StringSplit(line, " ",space_counter(line));
		
		wf << line << endl;
		delete [] tp;
}
	wf << name << " " << small << " " << medium << " " << large << " " << num;
	for(int i=0; i< atoi(num.c_str()); i++){
	wf << " " << topping[i];
}
	wf << endl; 

	wf.close();
	rf.close();

	remove("menu.txt");
	rename("temp.txt", "menu.txt");
}

/***********************************
 * Function: check_str
 * Description: check input for error handling
 * Parameters: string& str
 * Pre-Conditions: take an argument as string 
 * Post-Conditions: return true or false
***********************************/ 

bool check_str(string& str){
	for(int i=0; i<str.length(); i++){
		if(str[i] != '0' && str[i] != '1' && str[i] != '2' && str[i] != '3' && str[i] != '4' && str[i] != '5' && str[i] != '6' && str[i] != '7' && str[i] != '8' && str[i] != '9'){
			cout << " IT IS RAW! PLEASE CHECK YOUR INPUT !! " << endl;
			cout << " WRITE YOUR INPUT AGAIN: " <<endl;
			return false;}
}
	return true;
}

/***********************************
 * Function: add_item
 * Description: add items to the menu
 * Parameters: x
 * Pre-Conditions: the user input should be correct
 * Post-Conditions: changed the pizza menu
***********************************/ 

void add_item(){
	string name,small,medium,large,num;
	cout << "What is the new pizza name?" << endl;
	cin >> name;
	cout << "Small size cost: " << endl;
	cin >> small;
	while(check_str(small)==false){cin >> small;}
	cout << "Medium size cost: " << endl;
	cin >> medium;
	while(check_str(medium)==false){cin >> medium;}
	cout << "Large size cost: " << endl;
	cin >> large;
	while(check_str(large)==false){cin >> large;}
	cout << "how many topping has in new pizza: " << endl;
	cin >> num;
	while(check_str(num)==false){cin >> num;}
	string topping[atoi(num.c_str())];
	for(int i=0; i< atoi(num.c_str()); i++){
	cout << "Ingredient name: " << endl;
	cin >> topping[i];}
	update_menu(topping,name,small,medium,large,num);
	cout << "here is the updated menu" << endl;
	view_menu();

}

/***********************************
 * Function: update_menu_2
 * Description: update the text file for changing objects
 * Parameters: string& name
 * Pre-Conditions: the information from class should be correct
 * Post-Conditions: changed the information
***********************************/ 

void update_menu_2(string& name){
	string line;
	ifstream rf;
	ofstream wf;
	rf.open("menu.txt");
	wf.open("temp.txt");
	for(int i=0; i<menu_counter(); i++){
		getline(rf,line);
		string *tp = StringSplit(line, " ",space_counter(line));
		
		if(name != tp[0]){
			wf << line << endl;
			delete [] tp;
			continue;}
		delete [] tp;
}

	wf.close();
	rf.close();

	remove("menu.txt");
	rename("temp.txt", "menu.txt");
}

/***********************************
 * Function: remove_item
 * Description: remove order from the user
 * Parameters: x
 * Pre-Conditions: file in and out should be worked
 * Post-Conditions: changed the information
***********************************/ 

void remove_item(){
	string name;
	cout << "Which pizza do you want to remove from the menu? " << endl;
	cin >> name;
	update_menu_2(name);
	cout << "here is the updated menu" << endl;
	view_menu();
	
}

/***********************************
 * Function: employee_menu_2
 * Description: load employee menu for the user
 * Parameters: Restaurant* rest, string& answer
 * Pre-Conditions: the input from user should be correct
 * Post-Conditions: changed the information
***********************************/ 
	
void employee_menu_2(Restaurant* rest,string& answer){
	int counter=0;
	while(check_answer(answer) == false){
		cout << "IT IS RAW ! CHECK YOUR INPUT AGAIN !! " << endl;
		cin >> answer;
}
	while(answer != "10"){
	if(answer == "1"){
		change_hour(rest);
		counter=counter+1;}
	if(answer == "2"){view_orders();} 

	if(answer == "3"){remove_order();}
	if(answer == "4"){add_item();}
 	if(answer == "5"){remove_item();}
	if(answer == "6"){view_menu();}
	if(answer == "7"){
		if(counter ==0){
			view_hour(rest);}
		else{
			view_hour_2();}
}
	if(answer == "8"){view_address();}
	if(answer == "9"){view_phone();}
	emp_menu_1();
	cin >> answer;
}
}

/***********************************
 * Function: employee_menu_1
 * Description: load employee menu for the user
 * Parameters: Restaurant* rest
 * Pre-Conditions: the input from user should be correct
 * Post-Conditions: changed the information
***********************************/ 

void employee_menu_1(Restaurant* rest){
	string id,password,answer;
	cout << "Please provide your ID number: " << endl;
	cin >> id;
	Restaurant* arr = rest;	

	id_check(arr,id,password);
	emp_menu_1();
	cin >> answer;
	employee_menu_2(arr,answer);
	
}

/***********************************
 * Function: main_menu
 * Description: print 2 lines for interface
 * Parameters: x
 * Pre-Conditions: no syntax error
 * Post-Conditions: print 2 lines
***********************************/ 

void main_menu(){

	cout << " Welcome to Gordon Ramsay pizza ! " << endl;
	cout << "Who are you ? (C. Customer E. employee Q. get out) " << endl;
}

/***********************************
 * Function: itoa
 * Description: convert string to integer
 * Parameters: x
 * Pre-Conditions: integer should be a cc number
 * Post-Conditions: converting is completed
***********************************/ 

string itoa(){
	int cc=rand();
	string result;
	stringstream ss;
	ss << cc;
	result = ss.str();
	
	return result;
}

/***********************************
 * Function: create_order_num
 * Description: convert string to integer
 * Parameters: x
 * Pre-Conditions: integer should be an order number
 * Post-Conditions: converting is completed
***********************************/ 

string create_order_num(){
	int num=order_counter()+1;
	string result;
	stringstream ss;
	ss << num;
	result = ss.str();
	
	return result;
}

/***********************************
 * Function: check_size
 * Description: check input for error handling
 * Parameters: string& size
 * Pre-Conditions: take an argument as string 
 * Post-Conditions: return true or false
***********************************/ 

bool check_size(string& size){
	if(size != "S" && size != "M" && size != "L"){
		cout << "IT IS RAW! PLEASE CHECK YOUR INPUT !! " << endl;
		return false;}
	return true;
}

/***********************************
 * Function: update_order
 * Description: update the text file for changing objects
 * Parameters: string& order_num, string& name, string& cc, string& address, string& phone, string& pizza, string& size, string& quantity
 * Pre-Conditions: the information from class should be correct
 * Post-Conditions: changed the information
***********************************/ 

void update_order(string& order_num, string& name, string& cc, string& address, string& phone, string& pizza, string& size, string& quantity){
	string line;
	ifstream rf;
	ofstream wf;
	rf.open("orders.txt");
	wf.open("temp.txt");
	for(int i=0; i<order_counter(); i++){
		getline(rf,line);
		wf << line << endl;
}
	wf << order_num << " " << name << " " << cc << " " << address << " " << phone << " " << pizza << " " << size << " " << quantity << endl; 

	wf.close();
	rf.close();

	remove("orders.txt");
	rename("temp.txt", "orders.txt");
}

/***********************************
 * Function: place_order
 * Description: update the text file for changing objects
 * Parameters: string& name
 * Pre-Conditions: the information from class should be correct
 * Post-Conditions: changed the information
***********************************/ 

void place_order(){
	string order_num,name,cc,address,phone,pizza,size,quantity;
	cout << "What is your name?" << endl;
	cin >> name;
	cout << "Address for delivery:" << endl;
	cin >> address;
	cout << "Phone number:" << endl;
	cin >> phone;
	while(check_str(phone) == false){cin >> phone;}
	cout << "What do you want to order? " << endl;
	cin >> pizza;
	cout << "size: (S, M, L)" << endl;
	cin >> size;
	while(check_size(size) == false){cin >> size;}
	cout << "quantitiy: " << endl;
	cin >> quantity;
	while(check_str(quantity) == false){cin >> quantity;}
	cc = itoa();
	order_num = create_order_num();
	update_order(order_num,name,cc,address,phone,pizza,size,quantity);
	cout << "THANK YOU FOR YOUR ORDER !! " << endl;  
}

/***********************************
 * Function: print_p
 * Description: print_pizza from the objects
 * Parameters: Pizza& p
 * Pre-Conditions: the information from class should be correct
 * Post-Conditions: print the information of pizza
***********************************/ 

void print_p(Pizza& p){
		cout << p.get_name() << endl;
		cout << "small cost: " << p.get_small_cost() << endl;
		cout << "medium cost: " << p.get_medium_cost() << endl;
		cout << "large cost: " << p.get_large_cost() << endl;
		cout << "the number of ingredients: " << p.get_num_ingredients() << endl;
		
		string* arr= p.get_ingredients();
		cout << "ingredients: " << endl;
		for(int i=0; i<p.get_num_ingredients(); i++){
			cout << arr[i] <<" ";}
		cout << endl;
}

/***********************************
 * Function: print_pizza_cost
 * Description: filetering the pizza by the user input(cost)
 * Parameters: Pizza& p, string& size, string& max
 * Pre-Conditions: the information from class should be correct
 * Post-Conditions: print the information of pizza
***********************************/ 

void print_pizza_cost(Pizza& p,string& size, string& max){
		if(size == "S"){
			if(p.get_small_cost() <= atoi(max.c_str())){
				print_p(p);}
}
		if(size	== "M"){
			if(p.get_medium_cost() <= atoi(max.c_str())){
				print_p(p);}
}
		if(size == "L"){
			if(p.get_large_cost() <= atoi(max.c_str())){
				print_p(p);}
}				
		
	
}

/***********************************
 * Function: print_cost
 * Description: filetering the pizza by the user input(cost)
 * Parameters: Pizza& p, string& size, string& max, int num
 * Pre-Conditions: the information from class should be correct
 * Post-Conditions: print the information of pizza
***********************************/ 

void print_cost(Pizza p[], string& size, string& max, int num){
	for(int i=0; i<num; i++){
		print_pizza_cost(p[i],size,max);}
}

/***********************************
 * Function: check_o
 * Description: check input for error handling
 * Parameters: string& o
 * Pre-Conditions: take an argument as string 
 * Post-Conditions: return true or false
***********************************/ 

bool check_o(string& o){
	if(o != "Y" && o != "N"){
		cout << "IT IS RAW !! CHECK YOUR INPUT !! " << endl;
		cout << "WRITE YOUR INPUT AGAIN (Y/N) " << endl;
		return false;}
	return true;
}

/***********************************
 * Function: search_by_cost
 * Description: search by cost from the user inputs
 * Parameters: x
 * Pre-Conditions: the information from class should be correct
 * Post-Conditions: changed the information
***********************************/ 

void search_by_cost(){
	Pizza m[menu_counter()];
	pop_from_file(m,menu_counter());

	string size,max;
	cout << "which size of the cost do you want to search? (S, M, L) " << endl;
	cin >> size;
	while(check_size(size) == false){cin >> size;}
	cout << "how much is the maximum cost for order? " << endl;
	cin >> max;
	while(check_str(max) == false){cin >> max;}
	cout << "Here are the pizzas we found" << endl;
	print_cost(m,size,max,menu_counter());
	string o;
	cout << "Would you like to place order? (Y/N)" << endl;
	cin >> o;
	while(check_o(o) == false){cin >> o;}
	if(o =="Y"){ 
		place_order();}	
}

/***********************************
 * Function: print_pizza_include
 * Description: print pizza which has the specific ingredient
 * Parameters: Pizza& in, string& inc
 * Pre-Conditions: the information from class should be correct
 * Post-Conditions: filtering the menu by the ingredients
***********************************/ 

bool print_pizza_include(Pizza& in,string& inc){
		string* arr=in.get_ingredients();
		string *tp = StringSplit(inc, " ",space_counter(inc));
	
		for(int i=0; i<space_counter(inc)+1; i++){
			for(int j=0; j<in.get_num_ingredients(); j++){
				if(tp[i]==arr[j]){
					delete [] tp;
					return true;}
}
}
		delete [] tp;
		
	return false;
}

/***********************************
 * Function: print_include
 * Description: print pizza which has the specific ingredient
 * Parameters: Pizza in[], bool* in_list, string& inc, int num
 * Pre-Conditions: the information from class should be correct
 * Post-Conditions: filtering the menu by the ingredients
***********************************/ 

void print_include(Pizza in[],bool* in_list,string& inc, int num){
	for(int i=0; i<num; i++){
		if(print_pizza_include(in[i],inc)== true){
			in_list[i]=true;
			print_p(in[i]);}
}
}

/***********************************
 * Function: print_pizza_include_2
 * Description: print pizza except for the specific ingredient
 * Parameters: Pizza& in, string& ex
 * Pre-Conditions: the information from class should be correct
 * Post-Conditions: filtering the menu by the ingredients
***********************************/ 

bool print_pizza_include_2(Pizza& in, string& ex){
		string* arr=in.get_ingredients();
		string *tp = StringSplit(ex, " ", space_counter(ex));
		
		for(int i=0; i<space_counter(ex)+1; i++){
			for(int j=0; j<in.get_num_ingredients(); j++){
				if(tp[i]==arr[j]){
					delete [] tp;
					return true;}
}
}
	delete [] tp;
	
	return false;
}

/***********************************
 * Function: print_include_2
 * Description: print pizza except for the specific ingredient
 * Parameters: Pizza in[], bool* in_list, string& ex, int num
 * Pre-Conditions: the information from class should be correct
 * Post-Conditions: filtering the menu by the ingredients
***********************************/ 

void print_include_2(Pizza in[],bool* in_list,string& ex, int num){
	for(int i=0; i< num; i++){
		if(in_list[i] == true){
			if(print_pizza_include_2(in[i],ex) == false){
				print_p(in[i]);}
}
}
}

/***********************************
 * Function: search_include_ex
 * Description: print pizza except for the specific ingredient
 * Parameters: Pizza in[], bool* in_list
 * Pre-Conditions: take 2 arguments as class and bool array
 * Post-Conditions: filtering the menu by the ingredients
***********************************/ 

void search_include_ex(Pizza in[], bool* in_list){
	string ex="",d,e,f;
	
	cout << "Would you like to reduce your search by excluding some ingredients (Y/N) ? " << endl;
	cin >> d;
	while(check_o(d) == false){cin >> d;}	
	if(d =="Y"){
		do{
			cout << "What ingredient would you like to exclude? " << endl;
			cin >> e;
			ex=ex+e;
			cout << "Do you want to exclude another ingredient(Y/N)? " << endl;
			cin >> f;
			while(check_o(f) == false){cin >> f;}
			if(f=="Y"){ex=ex+" ";}
		}while(f == "Y");
		
	cout << "Here are the pizzas we found: " << endl;
	print_include_2(in,in_list,ex,menu_counter());
}
}

/***********************************
 * Function: search_include
 * Description: print pizza which has the specific ingredient
 * Parameters: Pizza in[]
 * Pre-Conditions: take 1 argument as class
 * Post-Conditions: filtering the menu by the ingredients
***********************************/ 

void search_include(Pizza in[]){ 
	bool* in_list= new bool[menu_counter()];
	for(int i=0; i<menu_counter(); i++){ in_list[i] = false;}
	string inc="",add,c;
		do{
			cout << "What ingredient would you like to include? " << endl;
			cin >> add;
			inc=inc+add;
			cout << "Do you want to include another ingredient (Y/N)? " << endl;
			cin >> c;
			while(check_o(c) == false){cin >> c;}
			if(c=="Y"){inc=inc+" ";}
		}while(c == "Y");

		cout << "Here are the pizzas we found: " << endl;
		print_include(in,in_list,inc,menu_counter());

	search_include_ex(in,in_list);
	delete [] in_list;
}

/***********************************
 * Function: print_pizza_exclude
 * Description: print pizza except for the specific ingredient
 * Parameters: Pizza& in, string& ex
 * Pre-Conditions: the information from class should be correct
 * Post-Conditions: filtering the menu by the ingredients
***********************************/ 

bool print_pizza_exclude(Pizza& in,string& ex){
		string* arr=in.get_ingredients();
		string *tp = StringSplit(ex, " ",space_counter(ex));
	
		for(int i=0; i<space_counter(ex)+1; i++){
			for(int j=0; j<in.get_num_ingredients(); j++){
				if(tp[i]==arr[j]){
					delete [] tp;
					return true;}
}
}
		delete [] tp;
		
	return false;
}

/***********************************
 * Function: print_exclude
 * Description: print pizza except for the specific ingredient
 * Parameters: Pizza in[], bool* ex_list, string& ex, int num
 * Pre-Conditions: the information from class should be correct
 * Post-Conditions: filtering the menu by the ingredients
***********************************/ 

void print_exclude(Pizza in[],bool* ex_list,string& ex, int num){
	for(int i=0; i<num; i++){
		if(print_pizza_exclude(in[i],ex)== false){
			ex_list[i]=true;
			print_p(in[i]);}
}
}

/***********************************
 * Function: print_pizza_exclude_2
 * Description: print pizza which has the specific ingredient
 * Parameters: Pizza& in, string& inc
 * Pre-Conditions: the information from class should be correct
 * Post-Conditions: filtering the menu by the ingredients
***********************************/ 

bool print_pizza_exclude_2(Pizza& in, string& inc){
		string* arr=in.get_ingredients();
		string *tp = StringSplit(inc, " ", space_counter(inc));
		
		for(int i=0; i<space_counter(inc)+1; i++){
			for(int j=0; j<in.get_num_ingredients(); j++){
				if(tp[i]==arr[j]){
					delete [] tp;
					return true;}
}
}
	delete [] tp;
	
	return false;
}

/***********************************
 * Function: print_exclude_2
 * Description: print pizza which has the specific ingredient
 * Parameters: Pizza in[], bool* ex_list, string& inc, int num
 * Pre-Conditions: the information from class should be correct
 * Post-Conditions: filtering the menu by the ingredients
***********************************/ 

void print_exclude_2(Pizza in[],bool* ex_list,string& inc, int num){
	for(int i=0; i< num; i++){
		if(ex_list[i] == true){
			if(print_pizza_exclude_2(in[i],inc) == true){
				print_p(in[i]);}
}
}
}

/***********************************
 * Function: search_exclude_in
 * Description: print pizza which has the specific ingredient
 * Parameters: Pizza in[], bool* ex_list
 * Pre-Conditions: take 2 arguments as class and bool array
 * Post-Conditions: filtering the menu by the ingredients
***********************************/ 

void search_exclude_in(Pizza in[], bool* ex_list){
	string inc="",d,e,f;
	
	cout << "Would you like to reduce your search by including some ingredients (Y/N) ? " << endl;
	cin >> d;
	while(check_o(d) == false){cin >> d;}	
	if(d =="Y"){
		do{
			cout << "What ingredient would you like to include? " << endl;
			cin >> e;
			inc=inc+e;
			cout << "Do you want to include another ingredient(Y/N)? " << endl;
			cin >> f;
			while(check_o(f) == false){cin >> f;}
			if(f=="Y"){inc=inc+" ";}
		}while(f == "Y");
		
	cout << "Here are the pizzas we found: " << endl;
	print_exclude_2(in,ex_list,inc,menu_counter());
}
}

/***********************************
 * Function: search_exclude
 * Description: print pizza except for the specific ingredient
 * Parameters: Pizza in[]
 * Pre-Conditions: take 1 argument as class
 * Post-Conditions: filtering the menu by the ingredients
***********************************/ 

void search_exclude(Pizza in[]){ 
	bool* ex_list= new bool[menu_counter()];
	for(int i=0; i<menu_counter(); i++){ ex_list[i] = false;}
	string ex="",add,c;
		do{
			cout << "What ingredient would you like to exclude? " << endl;
			cin >> add;
			ex=ex+add;
			cout << "Do you want to exclude another ingredient (Y/N)? " << endl;
			cin >> c;
			while(check_o(c) == false){cin >> c;}
			if(c=="Y"){ex=ex+" ";}
		}while(c == "Y");

		cout << "Here are the pizzas we found: " << endl;
		print_exclude(in,ex_list,ex,menu_counter());

	search_exclude_in(in,ex_list);
	delete [] ex_list;
}

/***********************************
 * Function: check_ie
 * Description: check input for error handling
 * Parameters: string& a
 * Pre-Conditions: take an argument as string 
 * Post-Conditions: return true or false
***********************************/ 

bool check_ie(string& a){
	if(a != "I" && a != "E"){
		cout << "IT IS RAW !! CHECK YOUR INPUT !! " << endl;
		cout << "WRITE YOUR INPUT AGAIN (Y/N) " << endl;
		return false;}
	return true;
}

/***********************************
 * Function: search_by_ingredient
 * Description: search by ex or including ingredient from the user inputs
 * Parameters: x
 * Pre-Conditions: the information from class should be correct
 * Post-Conditions: changed the information
***********************************/ 

void search_by_ingredient(){
	Pizza in[menu_counter()];
	pop_from_file(in,menu_counter());
	
	string a;
	cout << "Would you like to search for ingredients you want include(I) or exclude(E)? " << endl;
	cin >> a;
	while(check_ie(a) == false){cin >> a;}
	
	if(a =="I"){
		search_include(in);}
	if(a =="E"){
		search_exclude(in);}
	
	string o;
	cout << "Would you like to place order? (Y/N)" << endl;
	cin >> o;
	while(check_o(o) == false){cin >> o;}
	if(o =="Y"){ 
		place_order();}		
}

/***********************************
 * Function: cus_menu
 * Description: print customer menu
 * Parameters: x
 * Pre-Conditions: no syntax error
 * Post-Conditions: print sentences
***********************************/ 

void cus_menu(){
 	cout << "what do you want to do? " << endl;
	cout << "1. View Menu " << endl;
	cout << "2. Search by Cost" << endl;
	cout << "3. Search by Ingredients " << endl;
	cout << "4. Place Order " << endl;
	cout << "5. View Hours " << endl;
	cout << "6. View Adress " << endl;
	cout << "7. View Phone " << endl;
	cout << "8. Log out " << endl;
}

/***********************************
 * Function: customer_menu
 * Description: take input form the user as customer menu
 * Parameters: x
 * Pre-Conditions: functions should be connected
 * Post-Conditions: interface should be worked
***********************************/ 

void customer_menu(){				
	string answer;
	cus_menu();
	cin >> answer;
	while(check_answer(answer) == false){
		cout << "IT IS RAW ! CHECK YOUR INPUT AGAIN !! " << endl;
		cin >> answer;
}
	while(answer != "8"){
	if(answer == "1"){view_menu();}
	if(answer == "2"){search_by_cost();} 
	if(answer == "3"){search_by_ingredient();}
	if(answer == "4"){place_order();}
 	if(answer == "5"){view_hour_2();}
	if(answer == "6"){view_address();}
	if(answer == "7"){view_phone();}
	cus_menu();
	cin >> answer;
}
}


int main() {
	string c; 
	main_menu();
	cin >> c;
	while(check_main_menu(c) == false){ cin >> c;}

	Restaurant rest[255];
	pop_from_file_2(rest);
	pop_from_file_3(rest);
	
	while(c !="Q"){
		if(c == "C"){
			customer_menu();}
		if(c == "E"){
			employee_menu_1(rest);}
		main_menu();
		cin >> c;
		while(check_main_menu(c) == false){ cin >> c;}
}
}
		
