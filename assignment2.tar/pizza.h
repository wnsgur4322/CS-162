/***************************************************
 * Program filename: pizza.h
 * Author: Junhyeok Jeong
 * Date:4/29/2018
 * Description: header file for pizza class
 * Input: proto types of objects and functions in pizza class
 * Output: x
****************************************************/

#include <iostream>
#include <fstream>
#include <cstdlib>
#include <string>
#ifndef PIZZA_H
#define PIZZA_H

//#include "emp.h"

using namespace std;

class Pizza{
	private:
		string name;
		int small_cost;
		int medium_cost;
		int large_cost;
		int num_ingredients;
		string* ingredients;

	public:
		//constructor
		Pizza();
		~Pizza();
		//Pizza(string,int,int,int,int);
		//accessor
		string get_name() const;
		int get_small_cost() const;
		int get_medium_cost() const;
		int get_large_cost() const;
		int get_num_ingredients() const;
		string* get_ingredients();
		//mutator
		void set_name(string);
		void set_small_cost(int);
		void set_medium_cost(int);
		void set_large_cost(int);
		void set_num_ingredients(int);
		void set_ingredients(string*);
		
};
#endif
