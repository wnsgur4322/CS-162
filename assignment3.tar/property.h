/***************************************************
 * Program filename: property.h
 * Author: Junhyeok Jeong
 * Date:5/13/2018
 * Description: header file part for property class
 * Input: function's prototypes
 * Output: x
****************************************************/

#include <iostream>
#include <cstdlib>
#include <string>
#ifndef PROPERTY_H
#define PROPERTY_H
#include "tenant.h"

using namespace std;

class Property{
	protected:
		int value;
		int mortgage;
		int mortgage_period;
		static const float property_tax = 1.5;
		string location;
		int num_tenants;
		tenant* tenants;

	public:
		//constructor
		Property();
		Property(int,int,int,string);

		//accessor
		int get_value() const;
		int get_mortgage() const;
		string get_location() const;
		int get_num_tenants() const;
		string get_tenant_type(int) const;
		int get_tenant_agreeability_score(int) const;
		int get_tenant_budget(int) const;
		//mutator
		void set_value(int);
		void set_mortgage(int);
		void set_location(string);
		void set_num_tenants(int);
		void set_tenants(string, string, int ,int, int);

		//copy constructor
		Property(const Property&);
		//assignment operator overload
		const Property& operator=(const Property &);
		//destructor
		~Property();

		string get_rand_loc();
		int get_rand_val(int);
		int get_rand_mortgage();
		int get_rand_tenant(int);

		tenant* get_rand_tenants(const int, const string);


};

#endif
