/***************************************************
 * Program filename: tenant.h
 * Author: Junhyeok Jeong
 * Date:5/13/2018
 * Description: header file part for tenant structure
 * Input: function's prototypes
 * Output: x
****************************************************/

#include <iostream>
#include <fstream>
#include <cstdlib>
#include <string>

using namespace std;

struct tenant {
	string type;
	string business_type;
	int budget;
	int agreeability_score;
};




