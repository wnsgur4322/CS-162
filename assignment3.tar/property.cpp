/***************************************************
 * Program filename: property.cpp
 * Author: Junhyeok Jeong
 * Date:5/13/2018
 * Description: implementation part for property class
 * Input: function's parameters and definitions
 * Output: x
****************************************************/

#include <iostream>
#include <string>
#include <cstdlib>
#include <ctime>
#include "property.h"

using namespace std;

Property::Property(){
	value=0;
	mortgage=0;
	mortgage_period=0;
	num_tenants=0;
	location="";
	tenants=NULL;
}
Property::Property(int val,int mort, int num_ten, string loc){
		value=val;
		mortgage=mort;
		num_tenants=num_ten;
		mortgage_period=value/mortgage;
		tenants = new tenant[num_tenants];
		for(int i=0; i<num_tenants; i++){
			tenants[i].type="";
			tenants[i].business_type="";
			tenants[i].budget=0;
			tenants[i].agreeability_score=0; 
}
}	

		//accessor
		int Property::get_value() const {return value;}
		int Property::get_mortgage() const {return mortgage;}
		string Property::get_location() const {return location;}
		int Property::get_num_tenants() const {return num_tenants;}
		string Property::get_tenant_type(int index) const {return tenants[index].type;}
		int Property::get_tenant_agreeability_score(int index) const {return tenants[index].agreeability_score;}
		int Property::get_tenant_budget(int index) const {return tenants[index].budget;}
		//mutator
		void Property::set_value(int val) {value = val;}
		void Property::set_mortgage(int mort) {mortgage = mort;}
		void Property::set_location(string loc) {location = loc;}
		void Property::set_num_tenants(int num_ten) {num_tenants = num_ten;}
		void Property::set_tenants(string tp, string busy_tp, int as , int bud, int index){
			if(index <0 || index > num_tenants){
				cout << "Index error" << endl;}

			else{
				tenants[index].type= tp;
				tenants[index].business_type= busy_tp;
				tenants[index].agreeability_score = as;
				tenants[index].budget = bud;
}
}

		//copy constructor
		Property::Property(const Property& copy) {
			value= copy.value;
			mortgage=copy.mortgage;
			num_tenants=copy.num_tenants;
			if(num_tenants == 0){
				tenants = NULL;}
			else{
				tenants = new tenant[num_tenants];
				for(int i=0; i<num_tenants; i++){
					tenants[i] = copy.tenants[i];
}
}
}

		//assignment operator overload
		const Property& Property::operator=(const Property& copy){
			value= copy.value;
			mortgage=copy.mortgage;
			num_tenants=copy.num_tenants;
			if(tenants != NULL){
				delete [] tenants;}
			if(num_tenants == 0){
				tenants = NULL;}
			else{
				tenants = new tenant[num_tenants];
				for(int i=0; i<num_tenants; i++){
					tenants[i] = copy.tenants[i];
}
}
		return *this;
}
		//destructor
		Property::~Property(){
			delete [] tenants;
}
/***********************************
 * Function: get_rand_loc
 * Description: get random location
 * Parameters: x
 * Pre-Conditions: x
 * Post-Conditions: return value
***********************************/ 

string Property::get_rand_loc(){

	int num=0;
	num = rand() % 5 +1;
	if(num == 1){return "SE";}
	if(num == 2){return "NE";}
	if(num == 3){return "MW";}
	if(num == 4){return "SW";}
	if(num == 5){return "NW";}
}
/***********************************
 * Function: get_rand_val
 * Description: get random value
 * Parameters: minimum
 * Pre-Conditions: x
 * Post-Conditions: return value
***********************************/ 

int Property::get_rand_val(int minimum){
	//srand(time(NULL));
	int val=0;
	while(val < minimum || val > 600000){	
	val = rand() % 1000000;}
	return val;
}

/***********************************
 * Function: get_rand_mortgage
 * Description: get random mortgage
 * Parameters: x
 * Pre-Conditions: x
 * Post-Conditions: return value
***********************************/ 

int Property::get_rand_mortgage(){
	int mort=0;
	while(mort > 5000 || mort == 0){
		mort=rand()% 5000;}
	return mort;
}
 /***********************************
 * Function: get_rand_tenant
 * Description: get random tenant's number
 * Parameters: int max
 * Pre-Conditions: x
 * Post-Conditions: return value
***********************************/ 

int Property::get_rand_tenant(int max){
	int num=0;
	num = rand()%max+1;
	return num;
}
/***********************************
 * Function: get_rand_tenants
 * Description: get random tenants
 * Parameters: const in, const string
 * Pre-Conditions: x
 * Post-Conditions: return tenants sturcture
***********************************/ 

tenant* Property::get_rand_tenants(const int num,const string tp){
	tenant* t = new tenant[num];
	for(int i=0; i<num; i++){
		t[i].type = tp;
		if(tp == "citizen"){
			while(t[i].budget < 500 || t[i].budget > 5000){
				t[i].budget = rand()% 5000;}
}
		if(tp == "business"){
			while(t[i].budget <2000 || t[i].budget >10000){
				t[i].budget = rand()% 10000;
				
				int a=rand()%3+1;
				if(a==1){t[i].business_type="small";}
				if(a==2){t[i].business_type="medium";}
				if(a==3){t[i].business_type="large";}
}
}
		t[i].agreeability_score = rand()%5 +1;
}
	srand(time(NULL));
	return t;
}



