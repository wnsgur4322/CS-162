/***************************************************
 * Program filename: business.cpp
 * Author: Junhyeok Jeong
 * Date:5/13/2018
 * Description: implementation part for business class
 * Input: function's parameters and definitions
 * Output: x
****************************************************/

#include <iostream>
#include <string>
#include <cstdlib>
#include <ctime>
#include "property.h"
#include "business.h"

using namespace std;

Business::Business(){
	value=0;
	mortgage=0;
	mortgage_period=0;
	num_tenants=0;
	location="";
	tenants=NULL;
}

Business::Business(int val,int mort, int num_ten, string loc){
		value=val;
		mortgage=mort;
		location = loc;
		num_tenants=num_ten;
		mortgage_period=val/mort;
		tenants = new tenant[num_tenants];
		for(int i=0; i<num_tenants; i++){
			tenants[i].type="";
			tenants[i].business_type="";
			tenants[i].budget=0;
			tenants[i].agreeability_score=0;
}
}

//accessor
int Business::get_value() const {return value;}
int Business::get_mortgage() const {return mortgage;}
string Business::get_location() const {return location;}
int Business::get_num_tenants() const {return num_tenants;}
string Business::get_tenant_type(int index) const {return tenants[index].type;}
int Business::get_tenant_agreeability_score(int index) const {return tenants[index].agreeability_score;}
int Business::get_tenant_budget(int index) const {return tenants[index].budget;}
//mutator
void Business::set_value(int val) {value = val;}
void Business::set_mortgage(int mort) {mortgage = mort;}
void Business::set_location(string loc) {location = loc;}
void Business::set_num_tenants(int num_ten) {num_tenants = num_ten;}
void Business::set_tenants(string tp, string busy_tp, int as , int bud, int index){
	if(index <0 || index > num_tenants){
		cout << "Index error" << endl;}

	else{
		tenants[index].type= tp;
		tenants[index].business_type = busy_tp;
		tenants[index].agreeability_score = as;
		tenants[index].budget = bud;
}
}

		//copy constructor
		Business::Business(const Business& copy){
			value= copy.value;
			location = copy.location;
			mortgage=copy.mortgage;
			mortgage_period = copy.mortgage_period;
			num_tenants=copy.num_tenants;
			if(num_tenants == 0){
				tenants = NULL;}
			else{
				tenants = new tenant[num_tenants];
				for(int i=0; i<num_tenants; i++){
					tenants[i] = copy.tenants[i];
}
}
}

		//assignment operator overload
		const Business& Business::operator=(const Business& copy){
			value= copy.value;
			mortgage=copy.mortgage;
			location = copy.location;
			num_tenants=copy.num_tenants;
			mortgage_period = copy.mortgage_period;
			if(tenants != NULL){
				delete [] tenants;}
			if(num_tenants == 0){
				tenants = NULL;}
			else{
				tenants = new tenant[num_tenants];
				for(int i=0; i<num_tenants; i++){
					tenants[i] = copy.tenants[i];
}
}
		return *this;
}
		//destructor
		Business::~Business(){
			delete [] tenants;

}

/***********************************
 * Function: set_business
 * Description: get random Business object
 * Parameters: Business* h
 * Pre-Conditions: x
 * Post-Conditions: return object
***********************************/ 

void Business::set_business(Business* busy) {
	//srand(time(NULL));
			string busy_tp, loc;
			int num_ten = 0, val = 0, bud = 0, as = 0, mort = 0;
			loc = busy->get_rand_loc();
			val = busy->get_rand_val(400000);
			mort = busy->get_rand_mortgage();
			num_ten = busy->get_rand_tenant(5);


			(*busy) = Business(val, mort, num_ten, loc);
			for (int i = 0; i<num_ten; i++) {
					bud = rand() % 10000+2000;
				

				as = rand() % 5 + 1;
				int a = rand() % 3 + 1;
				if (a == 1) { busy_tp = "small"; }
				if (a == 2) { busy_tp = "medium"; }
				if (a == 3) { busy_tp = "large"; }
				busy->set_tenants("business", busy_tp, as, bud, i);
			}
}

/***********************************
 * Function: print
 * Description: print business object
 * Parameters: Business&
 * Pre-Conditions: x
 * Post-Conditions: print object
***********************************/ 


void Business::print(Business &busy){
	cout << "   Business complex information" << endl;
	cout << "---------------------------" << endl;
	cout << "Value : " << busy.value << endl;
	cout << "Location : " << busy.location << endl;
	cout << "Mortgage: " << busy.mortgage << endl;
	cout << "Mortgage period(months) : " << busy.mortgage_period << endl;
	cout << "The number of tenant(s) : " << busy.num_tenants << endl;
	cout << endl;

	cout << "The tenant's information" << endl;
	for(int i=0; i<num_tenants; i++){
		cout << "Tenant " << i+1 << endl;
		cout << "Type : " << busy.tenants[i].type << endl;
		cout << "Business type : " << busy.tenants[i].business_type << endl;
		cout << "Budget : " << busy.tenants[i].budget << endl;
		cout << "Agreeability score : " << busy.tenants[i].agreeability_score << endl;
	cout << endl;
}
	cout << "---------------------------" << endl;
}
