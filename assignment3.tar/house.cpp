/***************************************************
 * Program filename: house.cpp
 * Author: Junhyeok Jeong
 * Date:5/13/2018
 * Description: implementation part for house class
 * Input: function's parameters and definitions
 * Output: x
****************************************************/

#include <iostream>
#include <string>
#include <cstdlib>
#include <ctime>
#include "property.h"
#include "house.h"

using namespace std;


House::House(){
		value=0;
		mortgage=0;
		mortgage_period=0;
		num_tenants=0;
		location="";
		tenants=NULL;
}
House::House(int val,int mort, int num_ten, string loc){
		value=val;
		mortgage=mort;
		location=loc;
		num_tenants=num_ten;
		mortgage_period=val/mort;
		tenants = new tenant[num_tenants];
		for(int i=0; i<num_tenants; i++){
			tenants[i].type="";
			tenants[i].business_type="";
			tenants[i].budget=0;
			tenants[i].agreeability_score=0;
}
}

//accessor
int House::get_value() const {return value;}
int House::get_mortgage() const {return mortgage;}
string House::get_location() const {return location;}
int House::get_num_tenants() const {return num_tenants;}
string House::get_tenant_type(int index) const {return tenants[index].type;}
int House::get_tenant_agreeability_score(int index) const {return tenants[index].agreeability_score;}
int House::get_tenant_budget(int index) const {return tenants[index].budget;}
//mutator
void House::set_value(int val) {value = val;}
void House::set_mortgage(int mort) {mortgage = mort;}
void House::set_location(string loc) {location = loc;}
void House::set_num_tenants(int num_ten) {num_tenants = num_ten;}
void House::set_tenants(string tp, int as , int bud, int index){
	if(index <0 || index > num_tenants){
		cout << "Index error" << endl;}

	else{
		tenants[index].type= tp;
		tenants[index].agreeability_score = as;
		tenants[index].budget = bud;
}
}


		//copy constructor
		House::House(const House& copy){
			value= copy.value;
			mortgage=copy.mortgage;
			num_tenants=copy.num_tenants;
			location=copy.location;
			mortgage_period=copy.mortgage_period;
			if(num_tenants == 0){
				tenants = NULL;}
			else{
				tenants = new tenant[num_tenants];
				for(int i=0; i<num_tenants; i++){
					tenants[i] = copy.tenants[i];
}
}
}

		//assignment operator overload
		const House& House::operator=(const House& copy){
			//Property::operator=(copy);
			value= copy.value;
			mortgage=copy.mortgage;
			num_tenants=copy.num_tenants;
			location=copy.location;
			mortgage_period=copy.mortgage_period;
			if(tenants != NULL){
				delete [] tenants;}
			if(num_tenants == 0){
				tenants = NULL;}
			else{
				tenants = new tenant[num_tenants];
				for(int i=0; i<num_tenants; i++){
					tenants[i] = copy.tenants[i];
}
}
		return *this;
}
		//destructor
		House::~House(){
			delete [] tenants;
}

/***********************************
 * Function: set_house
 * Description: get random house object
 * Parameters: House* h
 * Pre-Conditions: x
 * Post-Conditions: return object
***********************************/ 

void House::set_house(House* h) {
			string busy_tp, loc;
			int num_ten = 1, val = 0, bud = 0, as = 0, mort = 0;
			loc = h->get_rand_loc();
			val = h->get_rand_val(100000);
			mort = h->get_rand_mortgage();


			(*h) = House(val, mort, num_ten, loc);
			for (int i = 0; i<num_ten; i++) {
					bud = rand() % 5000+500;
				

				as = rand() % 5 + 1;

				h->set_tenants("citizen", as, bud, i);
			}
}


/***********************************
 * Function: print_house
 * Description: print house object
 * Parameters: House& h
 * Pre-Conditions: x
 * Post-Conditions: print object
***********************************/ 


void House::print(House &h){
	cout << "  House information" << endl;
	cout << "--------------------" << endl;
	cout << "Value : " << h.value << endl;
	cout << "Location : " << h.get_location() << endl;
	cout << "Mortgage: " << h.mortgage << endl;
	cout << "Mortgage period(months) : " << h.mortgage_period << endl;
	cout << "The number of tenant(s) : " << h.num_tenants << endl;
	cout << endl;
	cout << "The tenant's information" << endl;
		cout << "Tenant 1" << endl;
		cout << "Type : " << h.tenants[0].type << endl;
		cout << "Budget : " << h.tenants[0].budget << endl;
		cout << "Agreeability score : " << h.tenants[0].agreeability_score << endl;
	cout << "--------------------" << endl;
	cout << endl;

}
