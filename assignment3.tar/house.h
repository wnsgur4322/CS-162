/***************************************************
 * Program filename: house.h
 * Author: Junhyeok Jeong
 * Date:5/13/2018
 * Description: header file part for house class
 * Input: function's prototypes
 * Output: x
****************************************************/

#include <iostream>
#include <fstream>
#include <cstdlib>
#include <string>
#ifndef HOUSE_H
#define HOUSE_H
#include "property.h"


class House : public Property{
	protected:
		int value;
		int mortgage;
		int mortgage_period;
		static const float property_tax = 1.5;
		string location;
		int num_tenants;
		tenant* tenants;
		friend class Player;

	public:
		House();
		House(int,int,int,string);

		//accessor
		int get_value() const;
		int get_mortgage() const;
		string get_location() const;
		int get_num_tenants() const;
		string get_tenant_type(int) const;
		int get_tenant_agreeability_score(int) const;
		int get_tenant_budget(int) const;
		//mutator
		void set_value(int);
		void set_mortgage(int);
		void set_location(string);
		void set_num_tenants(int);
		void set_tenants(string, int ,int, int);

		//copy constructor
		House(const House&);
		//assignment operator overload
		const House& operator=(const House &);
		//destructor
		~House();

		void set_tenant(tenant *);

		int get_max_tenant();
		tenant* get_tenant();

		void set_house(House *);
		
		void print(House &);

};

#endif
