/***************************************************
 * Program filename: player.cpp
 * Author: Junhyeok Jeong
 * Date:5/13/2018
 * Description: implementation part for player class
 * Input: function's parameters and definitions
 * Output: x
****************************************************/

#include <iostream>
#include <string>
#include <cstdlib>
#include <ctime>
#include "player.h"

using namespace std;

Player::Player(){
	bank=0;
	debt=0;
	month_mort = 0;
  h_counter=0;
  apt_counter=0;
  busy_counter=0;
  house_rent = 0;
  apt_rent = 0;
  busy_rent_s = 0;
  busy_rent_m = 0;
  busy_rent_l = 0;
	
}
Player::Player(int bk, int mort, int m_m,int rt,int rt2,int rt3,int rt4,int rt5, int h_counter, int apt_counter, int busy_counter) {
		bank=bk;
		debt=mort;
		month_mort = m_m;
		house_rent = rt;
		apt_rent = rt2;
		busy_rent_s = rt3;
		busy_rent_m = rt4;
		busy_rent_l = rt5;
}
		//accessor
		int Player::get_bank() const {return bank;}
		int Player::get_debt() const {return debt;}
		int Player::get_month_mort() const { return month_mort;}
		int Player::get_house_rent() const { return house_rent; }
		int Player::get_apt_rent() const { return apt_rent; }
		int Player::get_busy_rent_s() const { return busy_rent_s; }
		int Player::get_busy_rent_m() const { return busy_rent_m; }
		int Player::get_busy_rent_l() const { return busy_rent_l; }
		
		//mutator
		void Player::set_bank(int bk) {bank = bk;}
		void Player::set_debt(int mort) {debt = mort;}
		void Player::set_month_mort(int m_m) { month_mort = m_m; }
		void Player::set_house_rent(int rt) { house_rent = rt; }
		void Player::set_apt_rent(int rt2) { apt_rent = rt2; }
		void Player::set_busy_rent_s(int rt3) { busy_rent_s = rt3; }
		void Player::set_busy_rent_m(int rt4) { busy_rent_m = rt4; }
		void Player::set_busy_rent_l(int rt5) { busy_rent_l = rt5; }
		
		//copy constructor
		Player::Player(const Player& copy) {
			bank= copy.bank;
			debt=copy.debt;
			month_mort = copy.month_mort;
			house_rent = copy.house_rent;
			apt_rent = copy.apt_rent;
			busy_rent_s = copy.busy_rent_s;
			busy_rent_m = copy.busy_rent_m;
			busy_rent_l = copy.busy_rent_l;

}


		//assignment operator overload
		const Player& Player::operator=(const Player& copy){
			bank= copy.bank;
			debt=copy.debt;
			month_mort = copy.month_mort;
			house_rent = copy.house_rent;
			apt_rent = copy.apt_rent;
			busy_rent_s = copy.busy_rent_s;
			busy_rent_m = copy.busy_rent_m;
			busy_rent_l = copy.busy_rent_l;



		return *this;
}
		//destructor
		Player::~Player(){

}
/***********************************
 * Function: set_player
 * Description: set player class as object
 * Parameters: Player*
 * Pre-Conditions: take 1 arguments as an object
 * Post-Conditions: return set object
***********************************/ 
		void Player::set_player(Player* play) {
			int bk = 600000, mort = 0, m_m = 0, h_counter = 10, apt_counter = 10, busy_counter = 10, rt = 0, rt2 = 0, rt3 = 0,rt4=0,rt5=0;
			(*play) = Player(bk, mort, m_m,rt,rt2,rt3,rt4,rt5, h_counter, apt_counter, busy_counter);

		}

/***********************************
 * Function: Hurricane
 * Description: set player class as object
 * Parameters: House& , Apartment &, Business & , int &, int &, int &
 * Pre-Conditions: take 9 arguments as an object
 * Post-Conditions: return changed values
***********************************/ 


		void Player::hurricane(House& player_house, Apartment& player_apt, Business& player_busy, House& h, Apartment& apt, Business& busy, int& hc, int& apt_counter, int& busy_counter) {

			if (h.get_location() == "SE") {h.set_value((h.get_value()) / 2);}
			if(hc==1){
					if (player_house.get_location() == "SE") {
						player_house.set_value(player_house.get_value() / 2);}
			}
			if (apt.get_location() == "SE") {apt.set_value((apt.get_value()) / 2);}
			if (apt_counter == 1) {
				if (player_apt.get_location() == "SE") {
					player_apt.set_value(player_apt.get_value() / 2);}
			}

			if (busy.get_location() == "SE") {busy.set_value((busy.get_value()) / 2);}
			if (busy_counter == 1) {
				if (player_busy.get_location() == "SE") {
					player_busy.set_value(player_busy.get_value() / 2);}
			}
		}
/***********************************
 * Function: tornado
 * Description: set player class as object
 * Parameters: House& , Apartment &, Business & , int &, int &, int &
 * Pre-Conditions: take 9 arguments as an object
 * Post-Conditions: return changed values
***********************************/ 

		void Player::tornado(House& player_house, Apartment& player_apt, Business& player_busy, House& h, Apartment& apt, Business& busy, int& hc, int& apt_counter, int& busy_counter) {

			if (h.get_location() == "MW") {h.set_value((h.get_value()) - (3 * (h.get_value()) / 10));}
			if (hc == 1) {
				if (player_house.get_location() == "MW") {
					player_house.set_value(player_house.get_value() -(3* (player_house.get_value() / 10)));}
			}
			if (apt.get_location() == "MW") {apt.set_value((apt.get_value()) - (3 * (apt.get_value()) / 10));}
			if (apt_counter == 1) {
				if (player_apt.get_location() == "MW") {
					player_apt.set_value(player_apt.get_value() - (3 * (player_apt.get_value() / 10)));}
			}

			if (busy.get_location() == "MW") {busy.set_value((busy.get_value()) - (3 * (busy.get_value()) / 10));}
			if (busy_counter == 1) {
				if (player_busy.get_location() == "MW") {
					player_busy.set_value(player_busy.get_value() - (3 * (player_busy.get_value() / 10)));
				}
			}
		}
/***********************************
 * Function: earthquake
 * Description: set player class as object
 * Parameters: House& , Apartment &, Business & , int &, int &, int &
 * Pre-Conditions: take 9 arguments as an object
 * Post-Conditions: return changed values
***********************************/ 

		void Player::earthquake(House& player_house, Apartment& player_apt, Business& player_busy, House& h, Apartment& apt, Business& busy, int& hc, int& apt_counter, int& busy_counter) {

			if (h.get_location() == "NW") { h.set_value((h.get_value()) / 10); }
			if (hc == 1) {
				if (player_house.get_location() == "NW") {
					player_house.set_value(player_house.get_value() / 10);
				}
			}
			if (apt.get_location() == "NW") { apt.set_value((apt.get_value()) / 10); }
			if (apt_counter == 1) {
				if (player_apt.get_location() == "NW") {
					player_apt.set_value(player_apt.get_value() / 10);
				}
			}

			if (busy.get_location() == "NW") { busy.set_value((busy.get_value()) / 10); }
			if (busy_counter == 1) {
				if (player_busy.get_location() == "NW") {
					player_busy.set_value(player_busy.get_value() / 10);
				}
			}
		}
/***********************************
 * Function: wildfire
 * Description: set player class as object
 * Parameters: House& , Apartment &, Business & , int &, int &, int &
 * Pre-Conditions: take 9 arguments as an object
 * Post-Conditions: return changed values
***********************************/ 

		void Player::wildfire(House& player_house, Apartment& player_apt, Business& player_busy, House& h, Apartment& apt, Business& busy, int& hc, int& apt_counter, int& busy_counter) {

			if (h.get_location() == "SW") {h.set_value((h.get_value()) - ((h.get_value()) / 4));}
			if (hc == 1) {
				if (player_house.get_location() == "SW") {
					player_house.set_value(player_house.get_value() -(player_house.get_value() / 4));
				}
			}
			if (apt.get_location() == "SW") {apt.set_value((apt.get_value()) - ((apt.get_value()) / 4));}
			if (apt_counter == 1) {
				if (player_apt.get_location() == "SW") {
					player_apt.set_value(player_apt.get_value() -(player_apt.get_value() / 4));
				}
			}

			if (busy.get_location() == "SW") {
				busy.set_value((busy.get_value()) - ((busy.get_value()) / 4));}
			if (busy_counter == 1) {
				if (player_busy.get_location() == "SW") {
					player_busy.set_value(player_busy.get_value() -(player_busy.get_value() / 4));
				}
			}
		}
/***********************************
 * Function: stockcrash
 * Description: set player class as object
 * Parameters: House& , Apartment &, Business & , int &, int &, int &
 * Pre-Conditions: take 9 arguments as an object
 * Post-Conditions: return changed values
***********************************/ 

		void Player::stockcrash(House& player_house, Apartment& player_apt, Business& player_busy, House& h, Apartment& apt, Business& busy, int& hc, int& apt_counter, int& busy_counter) {

			h.set_value((h.get_value()) - ((3 * (h.get_value())) / 10));
			if (hc == 1) { 
					player_house.set_value(player_house.get_value() - (3 * (player_house.get_value() / 10)));
				}
			

			apt.set_value((apt.get_value()) - ((3 * (apt.get_value())) / 10));
			if (apt_counter == 1) {
					player_apt.set_value(player_apt.get_value() - (3 * (player_apt.get_value() / 10)));
				}
			

			busy.set_value((busy.get_value()) - ((3 * (busy.get_value())) / 10));
			if (busy_counter == 1) {
					player_busy.set_value(player_busy.get_value() - (3 * (player_busy.get_value() / 10)));
			}
		}
/***********************************
 * Function: gentrification
 * Description: set player class as object
 * Parameters: House& , Apartment &, Business & , int &, int &, int &
 * Pre-Conditions: take 9 arguments as an object
 * Post-Conditions: return changed values
***********************************/ 

		void Player::gentrification(House& player_house, Apartment& player_apt, Business& player_busy, House& h, Apartment& apt, Business& busy, int& hc, int& apt_counter, int& busy_counter) {

			string location = h.get_rand_loc();

			if (h.get_location() == location) {h.set_value((h.get_value()) + ((h.get_value()) / 5));}
			if (hc == 1) {
				if (player_house.get_location() == location) {
					player_house.set_value(player_house.get_value() +(player_house.get_value() / 5));
				}
			}
			if (apt.get_location() == location) {
				apt.set_value((apt.get_value()) + ((apt.get_value()) / 5));
			}
			if (apt_counter == 1) {
				if (player_apt.get_location() == location) {
					player_apt.set_value(player_apt.get_value() + (player_apt.get_value() / 5));
				}
			}
			if (busy.get_location() == location) {
				busy.set_value((busy.get_value()) + ((busy.get_value()) / 5));
			}
			if (busy_counter == 1) {
				if (player_busy.get_location() == location) {
					player_busy.set_value(player_busy.get_value() + (player_busy.get_value() / 5));
				}
			}
		}

/***********************************
 * Function: rand_event
 * Description: set player class as object
 * Parameters: House& , Apartment &, Business & , int &, int &, int &
 * Pre-Conditions: take 9 arguments as an object
 * Post-Conditions: return changed values
***********************************/ 

		void Player::rand_event(House& player_house, Apartment& player_apt, Business& player_busy, House& h, Apartment& apt, Business& busy,int& hc,int& apt_counter,int& busy_counter) {
			int cs;
			cs = rand() % 6 + 1;
			if (cs == 1) {
				hurricane(player_house,player_apt,player_busy,h, apt, busy,hc,apt_counter,busy_counter);
				cout << "Hurricane is coming ! (-50% values of South East property) " << endl;
			}
			if (cs == 2) {
				tornado(player_house, player_apt, player_busy, h, apt, busy, hc, apt_counter, busy_counter);
				cout << "tornado is coming ! (-30% values of Mid West property) " << endl;
			}
			if (cs == 3) {
				earthquake(player_house, player_apt, player_busy, h, apt, busy, hc, apt_counter, busy_counter);
				cout << "Earthquake is coming ! (-10% values of North West property) " << endl;
			}
			if (cs == 4) {
				wildfire(player_house, player_apt, player_busy, h, apt, busy, hc, apt_counter, busy_counter);
				cout << "wildfire is coming ! (-25% values of South West property) " << endl;
			}
			if (cs == 5) {
				stockcrash(player_house, player_apt, player_busy, h, apt, busy, hc, apt_counter, busy_counter);
				cout << "Sotck Market Crash is coming ! (-30% values of all area property) " << endl;
			}
			if (cs == 6) {
				gentrification(player_house, player_apt, player_busy, h, apt, busy, hc, apt_counter, busy_counter);
				cout << "Gentrification is coming ! (+20% values of random property) " << endl;
			}

		}
/***********************************
 * Function: menu_prompt
 * Description: print sentences
 * Parameters: x
 * Pre-Conditions: x
 * Post-Conditions: return sentences
***********************************/ 

		void Player::menu_prompt() {
			cout << "What do you want to do? " << endl;
			cout << "1. buy properties" << endl;
			cout << "2. sell properties" << endl;
			cout << "3. adjust rents on a property" << endl;
			cout << "4. finish this turn" << endl;
		}
/***********************************
 * Function: check_menu
 * Description: bool check for error handling
 * Parameters: string &
 * Pre-Conditions:  take 1 argument as string
 * Post-Conditions: return true or false
***********************************/ 
		bool Player::check_menu(string &a) {
			if (a != "1" && a != "2" && a != "3" && a != "4") {
				cout << "IT IS RAW ! CHECK YOUR INPUT !!" << endl;
				menu_prompt();
				return false;
			}
			return true;
		}
/***********************************
 * Function: check_buy
 * Description: bool check for error handling
 * Parameters: string &
 * Pre-Conditions:  take 1 argument as string
 * Post-Conditions: return true or false
***********************************/ 

		bool Player::check_buy(string &a) {
			if (a != "1" && a != "2" && a != "3") {
				cout << "IT IS RAW ! CHECK YOUR INPUT !!" << endl;
				cout << "What do you want to buy?(1. house 2. apartment 3. business) " << endl;
				return false;
			}
			return true;
		}
/***********************************
 * Function: check_sell
 * Description: bool check for error handling
 * Parameters: string &
 * Pre-Conditions:  take 1 argument as string
 * Post-Conditions: return true or false
***********************************/ 

		bool Player::check_sell(string &a) {
			if (a != "1" && a != "2" && a != "3") {
				cout << "IT IS RAW ! CHECK YOUR INPUT !!" << endl;
				cout << "What do you want to sell ? (1. house 2. apartment 3. business)" << endl;
				return false;
			}
			return true;
		}
/***********************************
 * Function: check_adjust
 * Description: bool check for error handling
 * Parameters: string &
 * Pre-Conditions:  take 1 argument as string
 * Post-Conditions: return true or false
***********************************/ 

		bool Player::check_adjust(string &a) {
			if (a != "1" && a != "2" && a != "3") {
				cout << "IT IS RAW ! CHECK YOUR INPUT !!" << endl;
				cout << "Which type property's rent you want to adjust ? (1. house 2. apartment 3. business) " << endl;
				return false;
			}
			return true;
		}
/***********************************
 * Function: check_borrow
 * Description: bool check for error handling
 * Parameters: string &
 * Pre-Conditions:  take 1 argument as string
 * Post-Conditions: return true or false
***********************************/ 

		bool Player::check_borrow(string& a) {
			if (a != "1" && a != "2") {
				cout << "IT IS RAW ! CHECK YOUR INPUT !!" << endl;
				cout << "Do you want to borrow money for purchasing this house? (1. Yes 2. No) " << endl;
				return false;
			}
			return true;
		}
/***********************************
 * Function: status
 * Description: print sentences with values
 * Parameters: Player &
 * Pre-Conditions: take 1 argument as class object
 * Post-Conditions: return sentences with values
***********************************/ 

		void Player::status(Player& play){
			cout << "Thank you for purchasing ! ! " << endl;
			cout << "Your bank accout: " << play.get_bank() << "$" << endl;
			cout << "Your debt: " << play.get_debt() << "$" << endl;
			cout << "Your monthly mortgage : " << play.get_month_mort() << "$" << endl;
		}
/***********************************
 * Function: set_rent
 * Description: set rent amount for tenant
 * Parameters: x
 * Pre-Conditions: set integer correctly
 * Post-Conditions: return integer
***********************************/ 

		int Player :: set_rent() {
			int rent = 0;
			cout << "How much do you want to set the rent of this property (maximum 1000$)?" << endl;
			cin >> rent;
			while (rent <= 0 || rent > 1000) {
				cout << "Rent is too low or high, set again" << endl;
					cin >> rent;
			}
			return rent;
		}
/***********************************
 * Function: set_b_rent_s
 * Description: set rent amount for tenant
 * Parameters: x
 * Pre-Conditions: set integer correctly
 * Post-Conditions: return integer
***********************************/ 

		int Player::set_b_rent_s() {
			int rent = 0;
			cout << "How much do you want to set the rent for small business? (maximum 500$)" << endl;
			cin >> rent;
			while(rent <=0 || rent >500){
				cout << "Rent is too low or high, set agian" << endl;
				cin >> rent;
			}
			return rent;
		}
/***********************************
 * Function: set_b_rent_m
 * Description: set rent amount for tenant
 * Parameters: x
 * Pre-Conditions: set integer correctly
 * Post-Conditions: return integer
***********************************/ 

		int Player::set_b_rent_m() {
			int rent = 0;
			cout << "How much do you want to set the rent for medium business? (maximum 1000$)" << endl;
			cin >> rent;
			while (rent <= 0 || rent >1000) {
				cout << "Rent is too low or high, set agian" << endl;
				cin >> rent;
			}
			return rent;
		}
/***********************************
* Function: set_b_rent_l
* Description: set rent amount for tenant
* Parameters: x
* Pre-Conditions: set integer correctly
* Post-Conditions: return integer
***********************************/ 

		int Player::set_b_rent_l() {
			int rent = 0;
			cout << "How much do you want to set the rent for large business? (maximum 1500$)" << endl;
			cin >> rent;
			while (rent <= 0 || rent >1500) {
				cout << "Rent is too low or high, set agian" << endl;
				cin >> rent;
			}
			return rent;
		}

/***********************************
 * Function: buy_house
 * Description: a function for buy property
 * Parameters: Player &, House &, Apartment &, int & ,int &, int &
 * Pre-Conditions: take 12 arguments as objects and integers
 * Post-Conditions: change object values correctly
***********************************/ 

		void Player::buy_house(Player& play, House& player_house, Apartment& player_apt, Business& player_busy, House& h, Apartment& apt, Business& busy, int& bank, int& debt, int& month_mort, int& hc, int& apt_counter, int& busy_counter) {
			if (hc == 1) {
				cout << "you have maximum house property, you can't buy anymore" << endl;
				//main_menu(play, player_house, player_apt, player_busy, h, apt, busy, bank, debt, month_mort, hc, apt_counter, busy_counter);
			}
			if (hc == 0) {
				int price = h.get_value();
				string a, b;
				cout << "Do you want to borrow money for purchasing this house? (1. Yes 2. No) " << endl;
				cin >> a;
				while (check_borrow(a) == false) { cin >> a; }

				if (a == "1") {
					cout << "How much do you want to borrow?" << endl;
					cin >> b;
					while (atoi(b.c_str()) > h.get_value()) {
						cout << "loan amount is over the house's price !!" << endl;
						cout << "How much do you want to borrow?" << endl;
						cin >> b;
					}
					price = price - atoi(b.c_str());
					play.set_debt(debt + atoi(b.c_str()));
					play.set_month_mort(month_mort + h.get_mortgage());
					play.set_bank(bank - price);
					player_house = h;
					hc = hc + 1;
				}
			
				if (a == "2") {
					play.set_bank(bank - price);
					player_house = h;
					hc = hc + 1;
				}
				play.set_house_rent(set_rent());
				status(play);
				h.set_house(&h);
			}
		
		}
/***********************************
 * Function: buy_apartment
 * Description: a function for buy property
 * Parameters: Player &, House &, Apartment &, int & ,int &, int &
 * Pre-Conditions: take 12 arguments as objects and integers
 * Post-Conditions: change object values correctly
***********************************/ 

		void Player::buy_apartment(Player& play, House& player_house, Apartment& player_apt, Business& player_busy, House& h, Apartment& apt, Business& busy, int& bank, int& debt, int& month_mort, int& hc, int& apt_counter, int& busy_counter) {
			if (apt_counter == 1) {
				cout << "you have maximum house property, you can't buy anymore" << endl;
				//main_menu(play, player_house, player_apt, player_busy, h, apt, busy, bank, debt, month_mort, hc, apt_counter, busy_counter);
			}
			if (apt_counter == 0) {
				int price = apt.get_value();
				string a, b;
				cout << "Do you want to borrow money for purchasing this apartment? (1. Yes 2. No) " << endl;
				cin >> a;
				while (check_borrow(a) == false) { cin >> a; }

				if (a == "1") {
					cout << "How much do you want to borrow?" << endl;
					cin >> b;
					while (atoi(b.c_str()) > apt.get_value()) {
						cout << "loan amount is over the house's price !!" << endl;
						cout << "How much do you want to borrow?" << endl;
						cin >> b;
					}
					price = price - atoi(b.c_str());
					play.set_debt(debt + atoi(b.c_str()));
					play.set_month_mort(month_mort + apt.get_mortgage());
					play.set_bank(bank - price);
					player_apt = apt;
					apt_counter = apt_counter + 1;
				}

				if (a == "2") {
					play.set_bank(bank - price);
					player_apt = apt;
					apt_counter = apt_counter + 1;
				}
				play.set_apt_rent(set_rent());
				status(play);
				apt.set_apartment(&apt);
			}
		}
/***********************************
 * Function: buy_business
 * Description: a function for buy property
 * Parameters: Player &, House &, Apartment &, int & ,int &, int &
 * Pre-Conditions: take 12 arguments as objects and integers
 * Post-Conditions: change object values correctly
***********************************/ 

		void Player::buy_business(Player& play, House& player_house, Apartment& player_apt, Business& player_busy, House& h, Apartment& apt, Business& busy, int& bank, int& debt, int& month_mort, int& hc, int& apt_counter, int& busy_counter) {
			if (busy_counter == 1) {
				cout << "you have maximum house property, you can't buy anymore" << endl;
				//main_menu(play, player_house, player_apt, player_busy, h, apt, busy, bank, debt, month_mort, hc, apt_counter, busy_counter);
			}
			if (busy_counter == 0) {
				int price = busy.get_value();
				string a, b;
				cout << "Do you want to borrow money for purchasing this business complex? (1. Yes 2. No) " << endl;
				cin >> a;
				while (check_borrow(a) == false) { cin >> a; }

				if (a == "1") {
					cout << "How much do you want to borrow?" << endl;
					cin >> b;
					while (atoi(b.c_str()) > busy.get_value()) {
						cout << "loan amount is over the house's price !!" << endl;
						cout << "How much do you want to borrow?" << endl;
						cin >> b;
					}
					price = price - atoi(b.c_str());
					play.set_debt(debt + atoi(b.c_str()));
					play.set_month_mort(month_mort + busy.get_mortgage());
					play.set_bank(bank - price);
					player_busy = busy;
					busy_counter = busy_counter + 1;
				}

				if (a == "2") {
					play.set_bank(bank - price);
					player_busy = busy;
					busy_counter = busy_counter + 1;
				}
				play.set_busy_rent_s(set_b_rent_s());
				play.set_busy_rent_m(set_b_rent_m());
				play.set_busy_rent_l(set_b_rent_l());
				status(play);
				busy.set_business(&busy);
			}
		}
/***********************************
 * Function: buy_property
 * Description: a function for buy property
 * Parameters: Player &, House &, Apartment &, business &, int & ,int &, int &
 * Pre-Conditions: take 12 arguments as objects and integers
 * Post-Conditions: change object values correctly
***********************************/ 

		void Player::buy_property(Player& play,House& player_house, Apartment& player_apt, Business& player_busy, House& h, Apartment& apt, Business& busy, int& bank, int& debt, int& month_mort, int& hc, int& apt_counter, int& busy_counter) {
			cout << "Here is the property's list you can buy" << endl;
			h.print(h);
			apt.print(apt);
			busy.print(busy);
			cout << endl;
			cout << "Your bank account: " << play.get_bank() << "$" << endl;

			string a;
			cout << "What do you want to buy ?(1. house 2. apartment 3. business) " << endl;
			cin >> a;
			while (check_buy(a) == false) { cin >> a; }
			if (a == "1") { buy_house(play, player_house, player_apt, player_busy, h, apt, busy, bank, debt, month_mort, hc, apt_counter, busy_counter); }
			if (a == "2") { buy_apartment(play, player_house, player_apt, player_busy, h, apt, busy, bank, debt, month_mort, hc, apt_counter, busy_counter); }
			if (a == "3") { buy_business(play, player_house, player_apt, player_busy, h, apt, busy, bank, debt, month_mort, hc, apt_counter, busy_counter); }

		}
/***********************************
 * Function: sell_house
 * Description: a function for sell property
 * Parameters: Player &, House &, Apartment &, Business &, int & ,int &, int &
 * Pre-Conditions: take 12 arguments as objects and integers
 * Post-Conditions: change object values correctly
***********************************/ 

		void Player::sell_house(Player& play, House& player_house, Apartment& player_apt, Business& player_busy, House& h, Apartment& apt, Business& busy, int& bank, int& debt, int& month_mort, int& hc, int& apt_counter, int& busy_counter) {
			if (hc == 1) {
				House temp;
				int selection = rand() % 3 + 1, wish = 0;
				if (player_house.tenants[0].type == "None") {
					if (selection == 1) {
						cout << "Congratulation !! you can set your price for selling !! set your wish price" << endl;
						cin >> wish;
						play.set_bank(play.get_bank() + wish);
					}
					if (selection == 2) {
						cout << "buyer offered the price as same price of property" << endl;
						play.set_bank(play.get_bank() + player_house.get_value());
					}
					if (selection == 3) {
						cout << "IT IS RAW ! YOUR PROPERTY IS SO RAW !! buyer offered - 10% price of the original price" << endl;
						play.set_bank(play.get_bank() + ((9 * player_house.get_value()) / 10));
					}
					player_house = temp;
					hc = hc - 1;
				}
				else {
					cout << "you can't sell this property because there is tenant" << endl;
				}
				cout << "Your bank account: " << play.get_bank() << "$" << endl;
			}
			if (hc == 0) {
				cout << "IT IS RAW !! YOU DON'T HAVE ANY PROPERTY !!" << endl;
				//main_menu(play, player_house, player_apt, player_busy, h, apt, busy, bank, debt, month_mort, hc, apt_counter, busy_counter);
			}
		}
/***********************************
 * Function: sell_apartment
 * Description: a function for sell property
 * Parameters: Player &, House &, Apartment &, Business &, int & ,int &, int &
 * Pre-Conditions: take 12 arguments as objects and integers
 * Post-Conditions: change object values correctly
***********************************/ 

		void Player::sell_apartment(Player& play, House& player_house, Apartment& player_apt, Business& player_busy, House& h, Apartment& apt, Business& busy, int& bank, int& debt, int& month_mort, int& hc, int& apt_counter, int& busy_counter) {
			if (apt_counter == 1) {
				Apartment temp;
				int selection = rand() % 3 + 1, wish = 0;
				bool empty = true;
				for (int i = 0; i < player_apt.get_num_tenants(); i++) {
					if (player_apt.tenants[i].type != "None") {
						empty = false;
					}
				}
				if (empty == true) {
					if (selection == 1) {
						cout << "Congratulation !! you can set your price for selling !! set your wish price" << endl;
						cin >> wish;
						play.set_bank(play.get_bank() + wish);
					}
					if (selection == 2) {
						cout << "buyer offered the price as same price of property" << endl;
						play.set_bank(play.get_bank() + player_apt.get_value());
					}
					if (selection == 3) {
						cout << "IT IS RAW ! YOUR PROPERTY IS SO RAW !! buyer offered - 10% price of the original price" << endl;
						play.set_bank(play.get_bank() + ((9 * player_apt.get_value()) / 10));
					}
					player_apt = temp;
					apt_counter = apt_counter - 1;
				}
				if (empty == false) {
					cout << "you can't sell this property because there is tenant" << endl;
				}
				cout <<"Your bank account: " << play.get_bank() << "$" << endl;
			}
			if (apt_counter == 0) {
				cout << "IT IS RAW !! YOU DON'T HAVE ANY PROPERTY !!" << endl;
				//main_menu(play, player_house, player_apt, player_busy, h, apt, busy, bank, debt, month_mort, hc, apt_counter, busy_counter);
			}
		}
/***********************************
 * Function: sell_busy
 * Description: a function for sell property
 * Parameters: Player &, House &, Apartment &, Business &, int & ,int &, int &
 * Pre-Conditions: take 12 arguments as objects and integers
 * Post-Conditions: change object values correctly
***********************************/ 

		void Player::sell_busy(Player& play, House& player_house, Apartment& player_apt, Business& player_busy, House& h, Apartment& apt, Business& busy, int& bank, int& debt, int& month_mort, int& hc, int& apt_counter, int& busy_counter) {
			if (busy_counter == 1) {
				Business temp;
				int selection = rand() % 3 + 1, wish = 0;
				bool empty = true;
				for (int i = 0; i < player_busy.get_num_tenants(); i++) {
					if (player_busy.tenants[i].type != "None") {
						empty = false;
					}
				}
				if (empty == true) {
					if (selection == 1) {
						cout << "Congratulation !! you can set your price for selling !! set your wish price" << endl;
						cin >> wish;
						play.set_bank(play.get_bank() + wish);
					}
					if (selection == 2) {
						cout << "buyer offered the price as same price of property" << endl;
						play.set_bank(play.get_bank() + player_busy.get_value());
					}
					if (selection == 3) {
						cout << "IT IS RAW ! YOUR PROPERTY IS SO RAW !! buyer offered - 10% price of the original price" << endl;
						play.set_bank(play.get_bank() + ((9 * player_busy.get_value()) / 10));
					}
					player_busy = temp;
					busy_counter = busy_counter - 1;
				}
				if (empty == false) {
					cout << "you can't sell this property because there is tenant" << endl;
				}
				cout << "Your bank account: " << play.get_bank() << "$" << endl;
			}
			if (busy_counter == 0) {
				cout << "IT IS RAW !! YOU DON'T HAVE ANY PROPERTY !!" << endl;
				//main_menu(play, player_house, player_apt, player_busy, h, apt, busy, bank, debt, month_mort, hc, apt_counter, busy_counter);
			}
		}
/***********************************
 * Function: sell_property
 * Description: a function for sell property
 * Parameters: Player &, House &, Apartment &, Business &, int & ,int &, int &
 * Pre-Conditions: take 12 arguments as objects and integers
 * Post-Conditions: change object values correctly
***********************************/ 

		void Player::sell_property(Player& play, House& player_house, Apartment& player_apt, Business& player_busy, House& h, Apartment& apt, Business& busy, int& bank, int& debt, int& month_mort, int& hc, int& apt_counter, int& busy_counter) {
			cout << "Here is the property's list you have" << endl;
			if (hc == 1) { player_house.print(player_house); }
			if (apt_counter == 1) { player_apt.print(player_apt); }
			if (busy_counter == 1) { player_busy.print(player_busy); }

			cout << "Your bank account :" << play.get_bank() << "$" << endl;

			string a;
			cout << "What do you want to sell? (1. house 2. apartment 3. business)" << endl;
			cin >> a;
			while (check_sell(a) == false) { cin >> a; }
			if (a == "1") { sell_house(play, player_house, player_apt, player_busy, h, apt, busy, bank, debt, month_mort, hc, apt_counter, busy_counter); }
			if (a == "2") { sell_apartment(play, player_house, player_apt, player_busy, h, apt, busy, bank, debt, month_mort, hc, apt_counter, busy_counter); }
			if (a == "3") { sell_busy(play, player_house, player_apt, player_busy, h, apt, busy, bank, debt, month_mort, hc, apt_counter, busy_counter); }
		}
/***********************************
 * Function: adjust_house
 * Description: a function for adjust property rent fees
 * Parameters: Player &, House &, Apartment &, Business &, int & ,int &, int &
 * Pre-Conditions: take 12 arguments as objects and integers
 * Post-Conditions: change object values correctly
***********************************/ 

		void Player::adjust_house(Player& play, House& player_house, Apartment& player_apt, Business& player_busy, House& h, Apartment& apt, Business& busy, int& bank, int& debt, int& month_mort, int& hc, int& apt_counter, int& busy_counter) {
			if (hc == 1) {

				cout << "Set your new rent for house !" << endl;
				play.set_house_rent(set_rent());
				cout << "Here is your new rent for house : " << play.get_house_rent() << "$" << endl;
			}
			if (hc == 0) {
				cout << "IT IS RAW !! YOU DON'T HAVE ANY PROPERTY !!" << endl;
				//main_menu(play, player_house, player_apt, player_busy, h, apt, busy, bank, debt, month_mort, hc, apt_counter, busy_counter);
			}
			
		}
/***********************************
 * Function: adjust_apartment
 * Description: a function for adjust property rent fees
 * Parameters: Player &, House &, Apartment &, Business &, int & ,int &, int &
 * Pre-Conditions: take 12 arguments as objects and integers
 * Post-Conditions: change object values correctly
***********************************/ 

		void Player::adjust_apartment(Player& play, House& player_house, Apartment& player_apt, Business& player_busy, House& h, Apartment& apt, Business& busy, int& bank, int& debt, int& month_mort, int& hc, int& apt_counter, int& busy_counter) {
			if (apt_counter == 1) {

				cout << "Set your new rent for apartment !" << endl;
				play.set_apt_rent(set_rent());
				cout << "Here is your new rent for apartment : " << play.get_apt_rent() << "$" << endl;
			}
			if (apt_counter == 0) {
				cout << "IT IS RAW !! YOU DON'T HAVE ANY PROPERTY !!" << endl;
				//main_menu(play, player_house, player_apt, player_busy, h, apt, busy, bank, debt, month_mort, hc, apt_counter, busy_counter);
			}

		}
/***********************************
 * Function: adjust_busy
 * Description: a function for adjust property rent fees
 * Parameters: Player &, House &, Apartment &, Business &, int & ,int &, int &
 * Pre-Conditions: take 12 arguments as objects and integers
 * Post-Conditions: change object values correctly
***********************************/ 

		void Player::adjust_busy(Player& play, House& player_house, Apartment& player_apt, Business& player_busy, House& h, Apartment& apt, Business& busy, int& bank, int& debt, int& month_mort, int& hc, int& apt_counter, int& busy_counter) {
			if (busy_counter == 1) {

				cout << "Set your new rent for business !" << endl;
				cout << "small business :" << endl;
				play.set_busy_rent_s(set_b_rent_s());
				cout << "medium business :" << endl;
				play.set_busy_rent_m(set_b_rent_m());
				cout << "large business :" << endl;
				play.set_busy_rent_l(set_b_rent_l());
				cout << "Here is your new rent for small business  : " << play.get_busy_rent_s() << "$" << endl;
				cout << "Here is your new rent for medium business  : " << play.get_busy_rent_m() << "$" << endl;
				cout << "Here is your new rent for large business  : " << play.get_busy_rent_l() << "$" << endl;
			}
			if (busy_counter == 0) {
				cout << "IT IS RAW !! YOU DON'T HAVE ANY PROPERTY !!" << endl;
				//main_menu(play, player_house, player_apt, player_busy, h, apt, busy, bank, debt, month_mort, hc, apt_counter, busy_counter);
			}

		}
/***********************************
 * Function: adjust_rent
 * Description: a function for adjust property rent fees
 * Parameters: Player &, House &, Apartment &, Business &, int & ,int &, int &
 * Pre-Conditions: take 12 arguments as objects and integers
 * Post-Conditions: change object values correctly
***********************************/ 

		void Player::adjust_rent(Player& play, House& player_house, Apartment& player_apt, Business& player_busy, House& h, Apartment& apt, Business& busy, int& bank, int& debt, int& month_mort, int& hc, int& apt_counter, int& busy_counter) {
			cout << "Here is the rent of each property" << endl;
			if (hc == 1) { cout << "House : " << play.get_house_rent() << "$" << endl; }
			if (apt_counter == 1) { cout << "Apartment : " << play.get_apt_rent() << "$" << endl; }
			if (busy_counter == 1) { cout << "Business (small, medium , large) : " << play.get_busy_rent_s() << ", " << play.get_busy_rent_m() << ", " << play.get_busy_rent_l() << endl; }

			string a;
			cout << "Which type property's rent you want to adjust ? (1. house 2. apartment 3. business) " << endl;
			cin >> a;
			while (check_adjust(a) == false) { cin >> a; }
			if (a == "1") { adjust_house(play, player_house, player_apt, player_busy, h, apt, busy, bank, debt, month_mort, hc, apt_counter, busy_counter); }
			if (a == "2") { adjust_apartment(play, player_house, player_apt, player_busy, h, apt, busy, bank, debt, month_mort, hc, apt_counter, busy_counter); }
			if (a == "3") { adjust_busy(play, player_house, player_apt, player_busy, h, apt, busy, bank, debt, month_mort, hc, apt_counter, busy_counter); }
		}

/***********************************
 * Function: main_menu
 * Description: a function for loading game main menus
 * Parameters: Player &, House &, Apartment &, Business &, int & ,int &, int &
 * Pre-Conditions: take 12 arguments as objects and integers
 * Post-Conditions: change object values correctly
***********************************/ 

		void Player::main_menu(Player& play, House& player_house, Apartment& player_apt, Business& player_busy, House& h, Apartment& apt, Business& busy, int& bank, int& debt, int& month_mort, int& h_counter, int& apt_counter, int& busy_counter) {

			string a;
			
				menu_prompt();
				cin >> a;
				while (check_menu(a) == false) {
					cin >> a;
				}
				if (a == "1") { buy_property(play, player_house, player_apt, player_busy, h, apt, busy, bank, debt, month_mort, h_counter, apt_counter, busy_counter); }
				if (a == "2") { sell_property(play, player_house, player_apt, player_busy, h, apt, busy, bank, debt, month_mort, h_counter, apt_counter, busy_counter); }

				if (a == "3") { adjust_rent(play, player_house, player_apt, player_busy, h, apt, busy, bank, debt, month_mort, h_counter, apt_counter, busy_counter); }

			
			cout << "Your turn is over " << endl;
		}
/***********************************
 * Function: collect_rent
 * Description: a function for collecting rent fees from tenants
 * Parameters: Player &, House &, Apartment &, Business &, int & ,int &, int &
 * Pre-Conditions: take 12 arguments as objects and integers
 * Post-Conditions: change object values correctly
***********************************/ 


		void Player::collect_rent(Player& play, House& player_house, Apartment& player_apt, Business& player_busy,int& hc,int& aptc, int& busyc) {
			cout << "Collecting rents ....." << endl;
			int sum = 0;
			if (hc == 1) {
				for (int i = 0; i < (player_house.get_num_tenants()); i++) {
					if (player_house.tenants[i].budget >= play.get_house_rent()) {
						sum = sum + play.get_house_rent();
						player_house.tenants[i].budget = player_house.tenants[i].budget - play.get_house_rent();
					}
					if (player_house.tenants[i].type != "None" &&player_house.tenants[i].budget <= play.get_house_rent()) {
						cout << "A tenant leave..." << endl;
						player_house.set_tenants("None", 0, 0, i);
					}
						
					}
				}
			
			if (aptc == 1) {
				for (int i = 0; i < (player_apt.get_num_tenants()); i++) {
					if (player_apt.tenants[i].budget >= play.get_apt_rent()) {
						sum = sum + play.get_apt_rent();
						player_apt.tenants[i].budget = player_apt.tenants[i].budget - play.get_apt_rent();
					}
					if (player_apt.tenants[i].type != "None" && player_apt.tenants[i].budget <= play.get_apt_rent()) {
						cout << "tenant " << i+1 <<  "  leave ... " << endl;
						player_apt.set_tenants("None", 0, 0, i);
					}
					}
			}
			
		if (busyc == 1) {
			for (int i = 0; i < (player_busy.get_num_tenants()); i++) {
				if (player_busy.tenants[i].business_type == "small" && player_busy.tenants[i].budget >= play.get_busy_rent_s()) {
					sum = sum + (play.get_busy_rent_s()*1.01);
					player_busy.tenants[i].budget = player_busy.tenants[i].budget - (play.get_busy_rent_s()*1.01);
				}
				if (player_busy.tenants[i].business_type == "medium" && player_busy.tenants[i].budget >= play.get_busy_rent_m()) {
					sum = sum + (play.get_busy_rent_m()*1.01);
					player_busy.tenants[i].budget = player_busy.tenants[i].budget - (play.get_busy_rent_m()*1.01);
				}
				if (player_busy.tenants[i].business_type == "large" && player_busy.tenants[i].budget >= play.get_busy_rent_l()) {
					sum = sum + (play.get_busy_rent_l()*1.01);
					player_busy.tenants[i].budget = player_busy.tenants[i].budget - (play.get_busy_rent_l()*1.01);
				}
				play.set_busy_rent_s(get_busy_rent_s()*1.01);
				play.set_busy_rent_m(get_busy_rent_m()*1.01);
				play.set_busy_rent_l(get_busy_rent_l()*1.01);
				if (player_busy.tenants[i].type != "None" && player_busy.tenants[i].budget <= play.get_busy_rent_l()) {
					cout << "tenant " << i+1 << "   leave..." << endl;
					player_busy.set_tenants("None","None", 0, 0, i);
				}
			}
			}
		play.set_bank(play.get_bank() + sum);
		cout << "Your bank account : " << play.get_bank() << "$" << endl;
			}

/***********************************
 * Function: pay_mortgage
 * Description: a function for paying month mortgage
 * Parameters: Player &
 * Pre-Conditions: take 1 argument as object
 * Post-Conditions: change object values correctly
***********************************/ 

		void Player::pay_mortgage(Player& play) {
			cout << "paying your mortgage ......" << endl;
				if (play.get_debt() > 0) {
					play.set_bank(play.get_bank() - play.get_month_mort());
					play.set_debt(play.get_debt() - play.get_month_mort());
				}
			if (play.get_debt() <= 0) {
				cout << "You don't have any mortgage !!" << endl;
			}
			cout << "Your bank account : " << play.get_bank() << "$" << endl;
		}

/***********************************
 * Function: pay_property_tax
 * Description: a function for paying month mortgage
 * Parameters: Player &, House& , Apartment&, int &
 * Pre-Conditions: take 9 arguments as objects and integers
 * Post-Conditions: change object values correctly
***********************************/ 

		void Player::pay_property_tax(Player& play, House& player_house, Apartment& player_apt, Business& player_busy, int& turn_counter, int& hc, int& apt_counter, int& busy_counter) {
			if (turn_counter != 0 && turn_counter % 12 == 0)
				if (hc == 1 || apt_counter == 1 || busy_counter == 1) {
					cout << "paying Property tax ......" << endl;
					int sum = 0;
					if (hc == 1) {
						sum = sum + (player_house.get_value() * (1.5 / 100.0));
					}
					if (apt_counter == 1) {
						sum = sum + (player_apt.get_value() * (1.5 / 100.0));
					}
					if (busy_counter == 1) {
						sum = sum + (player_busy.get_value() * (1.5 / 100.0));
					}
					play.set_bank(play.get_bank() - sum);
					cout << "Your bank account : " << play.get_bank() << "$" << endl;
				}
				else {
					cout << "You don't have any proeprty !!" << endl;
				}
		 }

/***********************************
 * Function: game_start
 * Description: print sentences
 * Parameters: x
 * Pre-Conditions: x
 * Post-Conditions: return sentences
***********************************/ 

		void Player::game_start() {
			cout << "WELCOME TO GORDON RAMSAY'S RAW ESTATE TYCOON" << endl;
			cout << "--------------------------------------------" << endl;
			cout << "If you become a millionaire, then win this game!" << endl;
			cout << "If you become a RAW, then lose this game!" << endl;
			cout << "--------------------------------------------" << endl;
			cout << "               Let the games Begin            " << endl;
		}
/***********************************
 * Function: game_end
 * Description: print sentences
 * Parameters: Player &
 * Pre-Conditions: take 1 argument as a class object
 * Post-Conditions: return sentences after checking values
***********************************/ 

		void Player::game_end(Player& play) {
			if (play.get_bank() >= 1000000) {
				cout << "-------------------------------------------------" << endl;
				cout << "| Congratulation !! YOU ARE NOT RAW ! YOU WIN ! |" << endl;
				cout << "-------------------------------------------------" << endl;
			}
			if (play.get_bank() <= 0) {
				cout << "----------------------------------------------" << endl;
				cout << "| YOU ARE REALLY RAW !! YOU LOSE THIS GAME ! |" << endl;
				cout << "----------------------------------------------" << endl;
			}
		}
		
