/***************************************************
 * Program filename: driver.cpp
 * Author: Junhyeok Jeong
 * Date:5/13/2018
 * Description: implementation part for driver class
 * Input: function's parameters and definitions
 * Output: x
****************************************************/

#include <iostream>
#include <cstdlib>
#include <ctime>
#include "property.h"
#include "house.h"
#include "apartment.h"
#include "business.h"
#include "player.h"

using namespace std;
 



int main(){
	srand(time(NULL));
	int bank=0,debt=0,month_mort=0,hc=0,aptc=0,busyc=0,turn_counter=1;
	Player* play = new Player;
	play->set_player(play);
	bank = play->get_bank();
	debt = play->get_debt();
	month_mort = play->get_month_mort();
	House player_house;
	Apartment player_apt;
	Business player_busy;
	
	
	House* houses = new House;
	houses->set_house(houses);	
	
	Apartment* apt = new Apartment;
	apt->set_apartment(apt);

	Business* busy = new Business;
	busy->set_business(busy);
	play->game_start();
	while (play->get_bank() >= 0 && play->get_bank() <= 1000000) {
		cout << "Month   " << turn_counter << endl;
		play->rand_event(player_house,player_apt,player_busy,*houses, *apt, *busy,hc,aptc,busyc);
		play->main_menu(*play, player_house, player_apt, player_busy, *houses, *apt, *busy, bank, debt, month_mort, hc, aptc, busyc);
		turn_counter = turn_counter + 1;
		play->collect_rent(*play, player_house, player_apt, player_busy, hc, aptc, busyc);
		play->pay_mortgage(*play);
		play->pay_property_tax(*play, player_house, player_apt, player_busy, turn_counter, hc, aptc, busyc);
	}
	play->game_end(*play);
	delete houses;
	delete apt;
	delete busy;
	delete play;
	return 0;
}
