/***************************************************
 * Program filename: business.h
 * Author: Junhyeok Jeong
 * Date:5/13/2018
 * Description: header file part for business class
 * Input: function's prototypes
 * Output: x
****************************************************/

#include <iostream>
#include <cstdlib>
#include <string>
#ifndef BUSINESS_H
#define BUSINESS_H
#include "property.h"



class Business : public Property{
	protected:
		int value;
		int mortgage;
		int mortgage_period;
		//static const float property_tax = 1.5;
		string location;
		int num_tenants;
		tenant* tenants;
		friend class Player;
	public:

		Business();
		Business(int,int,int,string);

		//accessor
		int get_value() const;
		int get_mortgage() const;
		string get_location() const;
		int get_num_tenants() const;
		string get_tenant_type(int) const;
		int get_tenant_agreeability_score(int) const;
		int get_tenant_budget(int) const;
		//mutator
		void set_value(int);
		void set_mortgage(int);
		void set_location(string);
		void set_num_tenants(int);
		void set_tenants(string, string, int ,int, int);

		//copy constructor
		Business(const Business&);
		//assignment operator overload
		const Business& operator=(const Business &);
		//destructor
		~Business();

		void set_business(Business *);
		
		void print(Business &);
};

#endif
