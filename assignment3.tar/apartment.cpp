/***************************************************
 * Program filename: apartment.cpp
 * Author: Junhyeok Jeong
 * Date:5/13/2018
 * Description: implementation part for apartment class
 * Input: function's parameters and definitions
 * Output: x
****************************************************/
#include <iostream>
#include <string>
#include <cstdlib>
#include <ctime>
#include "property.h"
#include "apartment.h"

using namespace std;

Apartment::Apartment(){
	value=0;
	mortgage=0;
	mortgage_period=0;
	num_tenants=0;
	location="";
	tenants= NULL;
}

Apartment::Apartment(int val,int mort, int num_ten, string loc){
		value=val;
		mortgage=mort;
		location = loc;
		num_tenants=num_ten;
		mortgage_period=val/mort;
		tenants = new tenant[num_tenants];
		for(int i=0; i<num_tenants; i++){
			tenants[i].type="";
			tenants[i].business_type="";
			tenants[i].budget=0;
			tenants[i].agreeability_score=0;
}
}

//accessor
int Apartment::get_value() const {return value;}
int Apartment::get_mortgage() const {return mortgage;}
string Apartment::get_location() const {return location;}
int Apartment::get_num_tenants() const {return num_tenants;}
string Apartment::get_tenant_type(int index) const {return tenants[index].type;}
int Apartment::get_tenant_agreeability_score(int index) const {return tenants[index].agreeability_score;}
int Apartment::get_tenant_budget(int index) const {return tenants[index].budget;}
//mutator
void Apartment::set_value(int val) {value = val;}
void Apartment::set_mortgage(int mort) {mortgage = mort;}
void Apartment::set_location(string loc) {location = loc;}
void Apartment::set_num_tenants(int num_ten) {num_tenants = num_ten;}
void Apartment::set_tenants(string tp, int as , int bud, int index){
	if(index <0 || index > num_tenants){
		cout << "Index error" << endl;}

	else{
		tenants[index].type= tp;
		tenants[index].agreeability_score = as;
		tenants[index].budget = bud;
}
}
		//copy constructor
		Apartment::Apartment(const Apartment& copy){
			value= copy.value;
			mortgage=copy.mortgage;
			mortgage_period = copy.mortgage_period;
			num_tenants=copy.num_tenants;
			location = copy.location;
			if(num_tenants == 0){
				tenants = NULL;}
			else{
				tenants = new tenant[num_tenants];
				for(int i=0; i<num_tenants; i++){
					tenants[i] = copy.tenants[i];
}
}
}

		//assignment operator overload
		const Apartment& Apartment::operator=(const Apartment& copy){
			//Property::operator=(copy);
			value= copy.value;
			mortgage=copy.mortgage;
			num_tenants=copy.num_tenants;
			mortgage_period = copy.mortgage_period;
			location = copy.location;
			if(tenants != NULL){
				delete [] tenants;}
			if(num_tenants == 0){
				tenants = NULL;}
			else{
				tenants = new tenant[num_tenants];
				for(int i=0; i<num_tenants; i++){
					tenants[i] = copy.tenants[i];
}
}
		return *this;
}
		//destructor
		Apartment::~Apartment(){
			delete [] tenants;
}
/***********************************
 * Function: set_apartment
 * Description: get random apartment object
 * Parameters: Apartment* h
 * Pre-Conditions: x
 * Post-Conditions: return object
***********************************/ 

void Apartment::set_apartment(Apartment* apt) {
	
			string busy_tp, loc;
			int num_ten = 0, val = 0, bud = 0, as = 0, mort = 0;
			loc = apt->get_rand_loc();
			val = apt->get_rand_val(300000);
			mort = apt->get_rand_mortgage();
			num_ten = apt->get_rand_tenant(10);


			(*apt) = Apartment(val, mort, num_ten, loc);
			for (int i = 0; i<num_ten; i++) {
					bud = rand() % 5000+500;
				

				as = rand() % 5 + 1;

				apt->set_tenants("citizen", as, bud, i);
			}
}

/***********************************
 * Function: print
 * Description: get random partment object
 * Parameters: Apartment* h
 * Pre-Conditions: x
 * Post-Conditions: return object
***********************************/ 

void Apartment::print(Apartment &apt){
	cout << "    Apartment information" << endl;
	cout << "---------------------------" << endl;
	cout << "Value : " << apt.value << endl;
	cout << "Location : " << apt.location << endl;
	cout << "Mortgage: " << apt.mortgage << endl;
	cout << "Mortgage period(months) : " << apt.mortgage_period << endl;
	cout << "The number of tenant(s) : " << apt.num_tenants << endl;
	cout << endl;

	cout << "The tenant's information" << endl;
	for(int i=0; i<num_tenants; i++){
		cout << "Tenant " << i+1 << endl;
		cout << "Type : " << apt.tenants[i].type << endl;
		cout << "Budget : " << apt.tenants[i].budget << endl;
		cout << "Agreeability score : " << apt.tenants[i].agreeability_score << endl;
}
	cout << "---------------------------" << endl;
	cout << endl;
}
