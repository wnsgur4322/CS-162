/***************************************************
 * Program filename: player.h
 * Author: Junhyeok Jeong
 * Date:5/13/2018
 * Description: header file part for player class
 * Input: function's prototypes
 * Output: x
****************************************************/

#include <iostream>
#include <cstdlib>
#include <string>
#ifndef PLAYER_H
#define PLAYER_H
#include "property.h"
#include "house.h"
#include "apartment.h"
#include "business.h"

using namespace std;

class Player {
protected:
		int bank;
		int debt;
		int month_mort;
    int h_counter;
    int apt_counter;
    int busy_counter;
	int house_rent;
	int apt_rent;
	int busy_rent_s;
	int busy_rent_m;
	int busy_rent_l;
		static const float property_tax = 1.5;

	public:
		//constructor
		Player();
		Player(int,int,int,int,int,int,int,int,int,int,int);

		//accessor
		int get_bank() const;
		int get_debt() const;
		int get_month_mort() const;
		int get_house_rent() const;
		int get_apt_rent() const;
		int get_busy_rent_s() const;
		int get_busy_rent_m() const;
		int get_busy_rent_l() const;

		//mutator
		void set_bank(int);
		void set_debt(int);
		void set_month_mort(int);
		void set_house_rent(int);
		void set_apt_rent(int);
		void set_busy_rent_s(int);
		void set_busy_rent_m(int);
		void set_busy_rent_l(int);

		//copy constructor
		Player(const Player&);
		//assignment operator overload
		const Player& operator=(const Player &);
		//destructor
		~Player();
		void set_player(Player *);
		void hurricane(House &, Apartment &, Business &,House &, Apartment &, Business &, int &, int &, int &);
		void tornado(House &, Apartment &, Business &, House &, Apartment &, Business &, int &, int &, int &);
		void earthquake(House &, Apartment &, Business &, House &, Apartment &, Business &, int &, int &, int &);
		void wildfire(House &, Apartment &, Business &, House &, Apartment &, Business &, int &, int &, int &);
		void stockcrash(House &, Apartment &, Business &, House &, Apartment &, Business &, int &, int &, int &);
		void gentrification(House &, Apartment &, Business &, House &, Apartment &, Business &, int &, int &, int &);
		void rand_event(House &, Apartment &, Business &, House &, Apartment &, Business &, int &, int &, int &);
		void menu_prompt();
		int set_rent();
		int set_b_rent_s();
		int set_b_rent_m();
		int set_b_rent_l();
		void status(Player &);
		bool check_menu(string &);
		bool check_buy(string &);
		bool check_sell(string &);
		bool check_adjust(string &);
		bool check_borrow(string &);
		void buy_house(Player &, House &, Apartment &, Business &, House &, Apartment &, Business &, int &, int &, int &, int &, int &, int &);
		void buy_apartment(Player &, House &, Apartment &, Business &, House &, Apartment &, Business &, int &, int &, int &, int &, int &, int &);
		void buy_business(Player &, House &, Apartment &, Business &, House &, Apartment &, Business &, int &, int &, int &, int &, int &, int &);
		void buy_property(Player &,House &,Apartment &, Business &, House &, Apartment &, Business &, int &, int &, int &, int &, int &, int &);
		void main_menu(Player &, House &, Apartment &, Business &, House &, Apartment &, Business &, int &, int &, int &, int &, int &, int &);
		void collect_rent(Player &, House &, Apartment &, Business &, int &, int &, int &);
		void pay_mortgage(Player &);
		void sell_house(Player &, House &, Apartment &, Business &, House &, Apartment &, Business &, int &, int &, int &, int &, int &, int &);
		void sell_apartment(Player &, House &, Apartment &, Business &, House &, Apartment &, Business &, int &, int &, int &, int &, int &, int &);
		void sell_busy(Player &, House &, Apartment &, Business &, House &, Apartment &, Business &, int &, int &, int &, int &, int &, int &);
		void sell_property(Player &, House &, Apartment &, Business &, House &, Apartment &, Business &, int &, int &, int &, int &, int &, int &);
		void adjust_house(Player &, House &, Apartment &, Business &, House &, Apartment &, Business &, int &, int &, int &, int &, int &, int &);
		void adjust_apartment(Player &, House &, Apartment &, Business &, House &, Apartment &, Business &, int &, int &, int &, int &, int &, int &);
		void adjust_busy(Player &, House &, Apartment &, Business &, House &, Apartment &, Business &, int &, int &, int &, int &, int &, int &);
		void adjust_rent(Player &, House &, Apartment &, Business &, House &, Apartment &, Business &, int &, int &, int &, int &, int &, int &);
		void pay_property_tax(Player &, House &, Apartment &, Business &, int &, int &, int &, int &);
		void game_start();
		void game_end(Player &);
};
#endif
